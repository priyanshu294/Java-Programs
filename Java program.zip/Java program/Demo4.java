public class Demo4
	{
	public static void main(String args[])
	{
	Test tt=new Test();
	tt.setName("Java");
	tt.setRoll(123);
	System.out.println("Name is "+tt.getName()+" Roll is "+tt.getRoll());
	}
	}