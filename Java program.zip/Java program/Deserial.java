import java.io.*;
public class Deserial
	{
	public static void main(String args[])
		{
		try{
		FileInputStream fis=new FileInputStream("ee.txt");
		ObjectInputStream ois=new ObjectInputStream(fis);
		Emp aa=(Emp)ois.readObject();
		System.out.println("Name is : "+aa.name+" Id : "+aa.id+"  Salary : "+aa.sal);
		fis.close();
		ois.close();
		}catch(Exception ee)
			{
			ee.printStackTrace();
			}
		}
	}
