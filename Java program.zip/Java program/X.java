class Block2
{
static{
System.out.println("I am in Block class");
}
}
public class X
{
Public static void main(String args[])
{
System.out.println(" I am in the main");
}
static{
System.out.println(" I am in the X class");
}
}
