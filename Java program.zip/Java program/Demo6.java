import java.io.*;
public class Demo6
	{
	public static void main(String args[])
		{
		try{
		DataInputStream dis=new DataInputStream(System.in);
		System.out.println("Enter first number.");
		int num1=Integer.parseInt(dis.readLine());
		System.out.println("Enter second number");
		int num2=Integer.parseInt(dis.readLine());
		System.out.println(num1/num2);
		}catch(ArithmeticException ae)
			{
			System.out.println("Reason is : "+ae.getMessage());
			}
		catch(NumberFormatException ne)
			{
			System.out.println("Reason is : "+ne.getMessage());
			}
		catch(IOException ie)
			{
			}
		}
	}
