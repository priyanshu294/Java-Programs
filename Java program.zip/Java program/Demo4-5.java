import java.io.*;
public class Demo4
	{
	public static void main(String args[])	
		{
		File f=new File("F:/Shams");
		String s[]=f.list();
		int j,i,v,t,fl;
		j=i=v=t=fl=0;
		for(String a:s)
			{
			if(!a.contains("."))
				{
				fl++;
				}
			else if(a.contains(".java"))
				{
				j++;
				}
			else if(a.contains(".mp4"))
				{
				v++;
				}
			else if(a.contains(".jpg"))
				{
				i++;
				}
			else if(a.contains(".txt"))
				{
				t++;
				}
			}
		System.out.println("Folder are "+fl);
		System.out.println("Image are "+i);
		System.out.println("Videos are "+v);
	System.out.println("Java files are "+j);
	System.out.println("txt are "+t);
		}
	}