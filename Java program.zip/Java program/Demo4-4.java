public class Demo4
	{
	public static void main(String args[])
		{
		double d=0;
		int i=args.length;
		System.out.println(d/i);
		}
	}
