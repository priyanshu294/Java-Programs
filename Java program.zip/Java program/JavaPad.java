import java.awt.*;
import java.awt.event.*;
import java.io.*;
public class JavaPad extends Frame implements ActionListener,WindowListener
	{
	TextArea ta;
	Menu m;
	MenuBar mb;
	MenuItem mi1,mi2,mi3,mi4;
	public JavaPad(String title)  
		{
		super(title);
		mb=new MenuBar();//step-1
		//step-2
		m=new Menu("File");
		//step-3
		mi1=new MenuItem("New");
		mi2=new MenuItem("Open");
		mi3=new MenuItem("Save");
		mi4=new MenuItem("Exit");
		//step-4
		m.add(mi1);
		m.add(mi2);
		m.addSeparator();
		m.add(mi3);
		m.add(mi4);
		//step-5
		mb.add(m);
		//step-6
		setMenuBar(mb);
		mi1.addActionListener(this);
		mi2.addActionListener(this);
		mi3.addActionListener(this);
		mi4.addActionListener(this);
		ta=new TextArea();
		ta.setFont(new Font("Arial",Font.BOLD,22));
		add(ta);
		setSize(500,400);
		setVisible(true);
		addWindowListener(this);
		}
	@Override
	public void actionPerformed(ActionEvent ae)
		{
		MenuItem mi=(MenuItem)ae.getSource();
		if(mi==mi1)
			{
			ta.setText("");
			}
		else if(mi==mi2)
			{
			try{
			FileDialog fd=new FileDialog(this,"Open",FileDialog.LOAD);
			fd.setVisible(true);
			String dir=fd.getDirectory();
			String fname=fd.getFile();
			FileInputStream fis=new FileInputStream(dir+fname);
			DataInputStream dis=new DataInputStream(fis);
			String str="",msg="";
		while((str=dis.readLine())!=null)
			{
			msg=msg+str;
			msg+="\n";
			}
		ta.setText(msg);
		dis.close();
		fis.close();
		}catch(Exception ee)
			{
			ee.printStackTrace();
			}
		}
		else if(mi==mi3)
		{
		try{
		FileDialog fd=new FileDialog(this,"Save As",FileDialog.SAVE);
		fd.setVisible(true);
		String txt=ta.getText();
		String dir=fd.getDirectory();
		String fname=fd.getFile();
		FileOutputStream fos=new FileOutputStream(dir+fname);
		DataOutputStream dos=new DataOutputStream(fos);
		dos.writeBytes(txt);
		dos.close();
		fos.close();
		}catch(Exception ee)
			{
			ee.printStackTrace();
			}
		}
		else if(mi==mi4)
			{
			System.exit(0);
			}
		}
	@Override
	public void windowActivated(WindowEvent we)	
		{
		}
	@Override
	public void windowDeactivated(WindowEvent we)	
		{
		}
	@Override
	public void windowIconified(WindowEvent we)
		{
		}
	@Override
	public void windowDeiconified(WindowEvent we)
		{
		}
	@Override
	public void windowOpened(WindowEvent we)
		{
		}
	@Override
	public void windowClosed(WindowEvent we)
		{
		}
	@Override
	public void windowClosing(WindowEvent we)
		{
		System.exit(0);
		}
	public static void main(String args[])	
		{
		new JavaPad("Java Notepad.");
		}
	}



			
				

		
		