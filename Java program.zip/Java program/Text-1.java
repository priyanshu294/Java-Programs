public class Text
	{
	int data;
	private Text()
		{
		data++;
		}
	protected Text(int x)
		{
		data=x;
		}
	public static void main(String args[])
		{
		Text tt=new Text();
		
		Text aa=new Text(10);
		System.out.println("Data value for first object is : "+tt.data);//1

		System.out.println("Data value for second Object is : "+aa.data);//10
		}
	}
