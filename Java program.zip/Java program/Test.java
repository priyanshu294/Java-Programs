public class Test
	{
	private String name;
	private int roll;
	
	public String getName()
		{
		return name;
		}
	public void setName(String n)
		{
		name=n;
		}
	
	public void setRoll(int r)
		{
		roll=r;
		}
	public int getRoll()
		{
		return roll;
		}
	}
		
	