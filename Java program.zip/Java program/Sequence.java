import java.io.*;
public class Sequence 
	{
	public static void main(String args[])
		{
		try{
		FileInputStream fis1=new FileInputStream("ByteDemo.java");
		FileInputStream fis2=new FileInputStream("Copy.java");
		SequenceInputStream s=new SequenceInputStream(fis1,fis2);
		int ch=0;
		while((ch=s.read())!=-1)
			{
			System.out.print((char)ch);
			}
		fis1.close();
		fis2.close();
		s.close();
		}catch(FileNotFoundException fe)
			{
			System.out.println("File Not Found.");
			}
		catch(IOException ie)	
			{
			}
		}
	}
