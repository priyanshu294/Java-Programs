import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class Mouse extends Applet implements MouseListener
	{
	int x,y;
	public void init()
		{
		setBackground(Color.pink);
		addMouseListener(this);
		}
	public void mouseEntered(MouseEvent me)
		{}
	public void mouseExited(MouseEvent me)
		{}
	public void mouseClicked(MouseEvent me)
		{}
	public void mousePressed(MouseEvent me)
		{
		x=me.getX();
		y=me.getY();
		}
	public void mouseReleased(MouseEvent me)
		{
		Graphics g=Mouse.this.getGraphics();
	g.drawRect(x,y,me.getX()-x,me.getY()-y);
		}
	}
/*
<applet code="Mouse" width="500" height="500"></applet>
*/ 
	
	
	
		
	