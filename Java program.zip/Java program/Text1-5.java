import java.io.*;
public class Text1//Write the data on the file
	{
	public static void main(String args[])
		{
		FileOutputStream fos=null;
		try{
		DataInputStream dis=new DataInputStream(System.in);
		System.out.println("Enter the data");
		String data=dis.readLine();
		fos=new FileOutputStream("aa.txt",true);
		byte bb[]=data.getBytes();
		fos.write(bb);
		}catch(NullPointerException ne)
			{
			System.out.println("Initialized FileOutputStream class.");
			}
		catch(FileNotFoundException fe)
			{
			System.out.println("Check the Path")	;
			}
		catch(IOException ie)
			{
			}
		finally{
		try{
		fos.close();
		}catch(IOException ee)	
			{
			}
		}
	}
	}

			
		
	