public class Demo
	{
	public static void main(String args[])
	{
	Demo dd=new Demo();
	Demo aa=new Demo();
	
	System.out.println(dd.hashCode());
	System.out.println(aa.hashCode());
	}
	}
	
	
	