import java.io.*;
public class Text2
	{
	public static void main(String args[])
		{
		FileInputStream fis=null;
		try{
		fis=new FileInputStream("aa.txt");
		System.out.println("Read the data from the file.");
		int ch=0;
		while((ch=fis.read())!=-1)
			{
			System.out.print((char)ch);
			}
		}catch(NullPointerException ne)
			{
			System.out.println("Initialize FileInputStream class.");
			}
		catch(FileNotFoundException fe)
			{
			System.out.println("File Not Found.");
			}
		catch(IOException ie)	
			{
			}
		finally{
		try{
		fis.close();
		}catch(IOException ee)
			{
			}
		}
	}
	}
	
			

		