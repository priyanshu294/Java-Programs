import java.awt.*;

public class FrameDemo extends Frame
	{
	FrameDemo(String title)
		{
		super(title);
		TextField tf=new TextField(12);
		Label l=new Label("Enter Name");
		Button b=new Button("Submit");
		
	Font f=new Font("Arial",Font.BOLD,22);
		tf.setFont(f);
		l.setFont(f);
		b.setFont(f);
		setVisible(true);
		setLayout(new FlowLayout());	
		setSize(400,500);
		add(l); 
		add(tf);		
		add(b);
		}
	public static void main(String args[])
		{
	FrameDemo fd=new FrameDemo("Hello JTian");	
		}
	}