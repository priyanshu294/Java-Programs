import java.awt.*;
import java.awt.event.*;//step-1
import java.applet.Applet;
import java.sql.*;
public class Login extends Applet implements ActionListener
	{
	Label l1,l2;
	TextField tf1,tf2;
	Button b;
	Font f;
	Connection cn;
	PreparedStatement ps;
	@Override
	public void init()	
		{
		l1=new Label("username");
		l2=new Label("password");
		tf1=new TextField(12);
		tf2=new TextField(12);
		b=new Button("submit");
		setLayout(null);
		f=new Font("Arial",Font.BOLD,20);
		b.addActionListener(this);
		l1.setFont(f);
		l2.setFont(f);
		tf1.setFont(f);
		tf2.setFont(f);
		b.setFont(f);
		l1.setBounds(30,40,95,30);
		tf1.setBounds(135,40,120,30);
		l2.setBounds(30,80,95,30);
		tf2.setBounds(135,80,120,30);
		b.setBounds(100,130,70,34);
		add(l1);
		add(tf1);
		add(l2);
		add(tf2);
		add(b);
		}
	@Override
	public void actionPerformed(ActionEvent ae)
		{
		String s1=tf1.getText();
		String s2=tf2.getText();
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","manager");
		ps=cn.prepareStatement("select * from login where name=(?) and password=(?)");
		ps.setString(1,s1);
		ps.setString(2,s2);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
			{
			showStatus("U are an authorized user.");
			}else{
			showStatus("u are not an authorized user.");
			}
		}catch(Exception ee)
			{
			ee.printStackTrace();
			}
		}
	}
/*<applet code="Login" width=270 height=250>
</applet>*/