import java.io.*;
import java.util.Scanner;
import java.util.*;

public class Pd
	{
	public static void main(String arg[]) throws IOException 
		{
System.out.print("To disable all USB ports you Must run the Programe As Adminstrator:\n\n");
		Scanner r = new Scanner(System.in);
		//DataInputStream dis = new DataInputStream(System.in);
		System.out.print("Do you want to disable all usb port ... \n press '1' for disable or '0' for set default value :"); 
		try{
		int c  = r.nextInt();
		//System.out.println(c);
		Pd p=new Pd();
		switch (c)
			{
			case 1:
				p.change(4);
				System.out.println(" Change sucessfully"); 
				break;
			case 0:
				p.change(3);
				System.out.println(" Change to default value"); 
				break;
			default:
				System.out.println(" Wrong Entry "); 
				System.exit(0);
			}
		System.out.print("\n\n to take effect u have to restart your system \n \n press '1' to restart now or '0' to restart later  :");
 		int ch = r.nextInt();
		switch (ch)
			{
			case 1:
			Runtime.getRuntime().exec("shutdown -r -t 10");
			System.out.println("System restart after 10sec .. ");
			break;
			
			default:
			System.exit(0);
			} 
		}catch(InputMismatchException im)
			{
			System.out.println("Please enter 0 or 1 ");
			}

		}
	public void change (int n) throws IOException
		{

Runtime.getRuntime().exec(" cmd /c start REG ADD HKLM\\SYSTEM\\CurrentControlSet\\services\\Usbccgp /v start /t reg_dword  /d  "+n+" /f ");

Runtime.getRuntime().exec(" cmd /c start REG ADD HKLM\\SYSTEM\\CurrentControlSet\\services\\Usbcir /v start /t reg_dword  /d  "+n+"  /f ");

Runtime.getRuntime().exec(" cmd /c start REG ADD HKLM\\SYSTEM\\CurrentControlSet\\services\\Usbehci /v start /t reg_dword  /d  "+n+" /f ");

Runtime.getRuntime().exec(" cmd /c start REG ADD HKLM\\SYSTEM\\CurrentControlSet\\services\\Usbhub /v start /t reg_dword  /d  "+n+" /f ");

Runtime.getRuntime().exec(" cmd /c start REG ADD HKLM\\SYSTEM\\CurrentControlSet\\services\\Usbohci /v start /t reg_dword  /d  "+n+" /f" );

Runtime.getRuntime().exec(" cmd /c start REG ADD HKLM\\SYSTEM\\CurrentControlSet\\services\\Usbprint /v start /t reg_dword  /d  "+n+" /f ");

Runtime.getRuntime().exec(" cmd /c start REG ADD HKLM\\SYSTEM\\CurrentControlSet\\services\\Usbstor /v start /t reg_dword  /d  "+n+" /f ");

Runtime.getRuntime().exec(" cmd /c start REG ADD HKLM\\SYSTEM\\CurrentControlSet\\services\\Usbuhci /v start /t reg_dword  /d  "+n+" /f ");

Runtime.getRuntime().exec(" cmd /c start REG ADD HKLM\\SYSTEM\\CurrentControlSet\\services\\Usbvideo /v start /t reg_dword  /d  "+n+" /f ");
}


}