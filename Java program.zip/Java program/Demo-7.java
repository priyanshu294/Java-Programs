import java.awt.*;

public class Demo extends Frame
	{
	Button b1,b2,b3;
	public Demo(String title)
		{
		super(title);		
		setLayout(new FlowLayout());
		b1=new Button("First");
		b2=new Button("Second");
		b3=new Button("Third");
		
		Font f=new Font("Arial",Font.BOLD,22);
		b1.setFont(f);
		b2.setFont(f);
		b3.setFont(f);
		
		add(b1);
		add(b2);		
		add(b3);
		setSize(400,400);
		setVisible(true);
		}
	public static void main(String args[])
		{
	Demo dd=new Demo("FlowLayout Example");
		}
	}
	
		
		
		