public class Test3
	{
	public static void main(String args[])
	{
	int j=0;
	do{
	for(int i=0;i++<3;)
		{
		System.out.print(i);
		}
	}while(j++<2);
	}
	}
