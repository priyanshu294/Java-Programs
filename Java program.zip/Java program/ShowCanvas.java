import java.applet.*;
public class ShowCanvas extends Applet
	{
	public void init()
		{
		Canvas1 cv=new Canvas1();
		add(cv);
		}
	}
/*
<applet code="ShowCanvas" width="400" height="400">
</applet>
*/