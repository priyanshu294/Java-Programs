public class Demo5
	{
	public static void main(String args[])
		{
		try{
		int i=100;
		int j=args.length;
		System.out.println(i/j)	;
			try{
			System.out.println("I am in the nested try block.");
			System.out.println(args[1]);
		}catch(StringIndexOutOfBoundsException ce)
			{
			System.out.println("Caught.");
			}
		}catch(RuntimeException re)	
			{
			System.out.println("Handle Exception.");
			re.printStackTrace();
			}
		}
	}

			