import java.io.*;
public class FileDemo
	{
	public static void main(String args[])
		{
		try{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the data");
		String data=br.readLine();
		FileWriter fw=new FileWriter("a1.txt");
		fw.write(data)	;
		fw.close();
		System.out.println("\nRead the data from the file.\n");
		FileReader fr=new FileReader("a1.txt");
		int ch=0;
		while((ch=fr.read())!=-1)
			{
			System.out.print((char)ch);
			}
		fr.close();
		}catch(FileNotFoundException fe)
			{
			System.out.println("File Not Found.");
			}
		catch(IOException ie)
			{
			}
		}
	}
