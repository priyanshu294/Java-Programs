public class Unchecked
	{
	static void m1()
		{
		System.out.println("Unchecked Exception.");
		try{
		throw new Error();
		}catch(Exception ee)
			{
			System.out.println("Caught Error.");
			}
		System.out.println("Method is Error free.");
		}
	static void m2()
		{
		throw new Error();
		}
	public static void main(String args[])
		{
		m1();
		try{
		m2();
		}catch(Error ee)
			{
			System.out.println("Handle Error at calling time.");
			}
		}
	}

	