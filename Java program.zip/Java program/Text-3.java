public class Text implements Cloneable
	{
	int data;
	public static void main(String args[])
		{
		Text tt=new Text();
		tt.data+=10;
		System.out.println("Data value for original Object is : "+tt.data);
		Text aa=null;
		try{
		aa=(Text)tt.clone();
		}catch(CloneNotSupportedException ce)
			{
			System.out.println("Object is not Cloned.");
			}
		System.out.println("Data value for duplicate Object is : "+aa.data)	;
		System.out.println(aa.hashCode()+"\t"+tt.hashCode());
		if(aa.equals(tt))
			{
			System.out.println("True");
			}else{
			System.out.println("False");
			}
		}
	}

	
		