public class Demo2
	{
	public static void main(String args[])
		{
		double d=10;
		int i=args.length;
		System.out.println(d/i);
		}
	}
