public class Test4
	{
	public static void main(String args[])
	{
	int i=1;
	while(true)
		{
		if(i==3)
			{
			break;
			}
		i++;
		}
	System.out.println(i);
	}
	}
