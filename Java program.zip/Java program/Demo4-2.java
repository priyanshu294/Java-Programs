public class Demo4
	{
	public static void main(String args[])
	{
	class Inner
		{
		void show()
			{
		int size=args.length;
		System.out.println("\n See the Command line Arguments\n");
		
	for(int i=0;i<size;i++)
		{
	System.out.println(args[i]);
		}
			}
		}
	Inner ii=new Inner();
	ii.show();
	}
	}