import java.applet.*;
import java.awt.*;

public class Demox extends Applet
	{
	public void init()
		{
		setBackground(Color.yellow);
		}
	public void paint(Graphics g)
		{
		g.setColor(Color.blue);
	Font f1=new Font("Arial",Font.BOLD,32);
		g.setFont(f1);
		g.drawString("The Java",20,30);
		
	String s="\u091c"+"\u093e"+"\u092d"+"\u093e";
	Font f2=new Font("kokila",Font.BOLD,32);
	g.setFont(f2);
	g.setColor(Color.red);
	g.drawString(s,30,70);
	
	String ss="\u0b1c"+"\u0b3e"+"\u0b2d"+"\u0b3e";
	Font f3=new Font("Kalinga",Font.BOLD,34);
	g.setFont(f3);
	g.setColor(Color.magenta);
	g.drawString(ss,40,120);
		}
	}
/*
<applet code="Demox" width="400" height="500">
</applet>
*/