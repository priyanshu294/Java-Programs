public class Text2
	{
	int data;
	public Text2()
		{
		data++;
		System.out.println("Object is constructed.");
		}
	void increment()
		{
		data++;
		}
	public static void main(String args[])
		{
		Text2 tt=new Text2();
		tt.increment();
		tt.increment();
		tt.increment();
		tt.increment();
		System.out.println("data value is : "+tt.data);
		}
	}

