import java.io.*;
public class Demo
	{
	public static void main(String args[])
		{
		try{
		File f=new File("JT.txt");
		if(f.createNewFile())
			{
System.out.println("File is Succesfully created");
			}else{
System.out.println("File is Already present");
			}
		}catch(Exception ee)
			{
			}
		}
	}
		