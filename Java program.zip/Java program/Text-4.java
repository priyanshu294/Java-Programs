import java.awt.*;
import java.applet.*;

public class Text extends Applet
	{
	Button b1,b2;
	TextField tf1,tf2;
	Label l1,l2,l3;
	ScrollPane sp;
	List l;
	Choice ch;
	Checkbox cb1,cb2,cb3,cb4;
	CheckboxGroup cbg;
	Font f;
	TextArea ta;
	public void init()
		{
		f=new Font("Arial",Font.BOLD,20);
		l1=new Label("Enter Name");
		l1.setFont(f);
		l2=new Label("Enter Password");
		l2.setFont(f);
		
		tf1=new TextField(10);
		tf2=new TextField(10);
		
		tf1.setFont(f);
		tf2.setFont(f);
		tf2.setEchoChar('#');
		ta=new TextArea(10,20);
		ta.setText("A/54,Saheed NAgar");
		ta.setFont(f);
		tf1.setText("Java Technocrat");
		tf1.setEditable(false);
		
		sp=new ScrollPane();
		b2=new Button("Java Technocrat");
		b2.setFont(new Font("Arial",Font.BOLD,100));
		sp.add(b2);
		
		b1=new Button("Login");
		b1.setFont(f);
		
		l=new List(3,true);
		l.addItem("java");
		l.addItem("Python");
		l.addItem("Oracle");
		l.addItem("Advanced Java");
		l.setFont(f);
		
		ch=new Choice();
		ch.addItem("Select One");				ch.addItem("India");
		ch.addItem("USA");
		ch.addItem("UK");
		ch.addItem("SA");
		ch.addItem("UAE");
		
		ch.setFont(f);
		
		cb1=new Checkbox("Java",true);
		cb2=new Checkbox("Python");
		
		cb1.setFont(f);
		cb2.setFont(f);
		
		cbg=new CheckboxGroup();
	cb3=new Checkbox("Male",cbg,true);
	cb4=new Checkbox("Female",cbg,false);
		
		cb3.setFont(f);
		cb4.setFont(f);
	l3=new Label("Student Registration Form");
	l3.setFont(f);
		
		add(l3);
		add(l1);
		add(tf1);
		add(l2);
		//add(tf2);
		//add(b1);
		//add(sp);
		//add(ta);	
		//add(ch);
		//add(l);
		//add(cb1);
		//add(cb2);
		//add(cb3);
		//add(cb4);
		}
	}
/*<applet code="Text" width="600" height="600">
</applet>
*/
																					
		
		
		
			
		
	

