public class Test2
	{
	public static void main(String args[])
	{
	int j=0;
	for(int i=0;i<=3;i++)
		{
		do
			System.out.println(i);
		while(j++<=2);
		}
	}
	}
