import java.awt.*;
import java.applet.*;
import java.awt.event.*;

public class Key extends Applet implements KeyListener
	{
	int x=100, y=100,width,height;
		
	public void init()
		{
		setBackground(Color.cyan);
		addKeyListener(this);
		}
	public void paint(Graphics g)
		{
		g.setColor(Color.red);
		g.fillOval(x,y,80,80);
		}
	public void keyTyped(KeyEvent ke)
		{
		}
	public void keyReleased(KeyEvent ke)
		{
		}
	public void keyPressed(KeyEvent ke)
		{
		int k=ke.getKeyCode();
		width=getSize().width;
		height=getSize().height;
		
		if(k==KeyEvent.VK_LEFT)
			{
			x-=20;
			if(x<1)
				{
				x=width-20;
				}
			}
		else if(k==KeyEvent.VK_RIGHT)
			{
			x+=20;
			if(x>width)
				{
				x=20;
				}
			}
		else if(k==KeyEvent.VK_UP)
			{
			y-=20;
			if(y<1)
				{
				y=height-20;
				}
			}
		else if(k==KeyEvent.VK_DOWN)
			{
			y+=20;
			if(y>height)
				{
				y=20;
				}
			}
		repaint();
		}
	}
/*
<applet code="Key" width="500" height="600"></applet>
*/
	 