public class Demo1
	{
	static Demo1 dd;
	Demo1 aa;
	
public static void main(String args[])
	{
	Demo1 bb=new Demo1();
	System.out.println(bb);
	System.out.println(dd);
	System.out.println(bb.aa);	
	}
	}
	