import java.io.*;
public class PrintDemo
	{
	public static void main(String args[])
		{
		try{
		PrintStream ps1=new PrintStream(new FileOutputStream("ff.txt"));
		ps1.println("Java Language.");
		ps1.print("C/");
		ps1.println("C++ Application.");
		ps1.println("Python Application.");
		ps1.close();
		
		PrintStream ps2=new PrintStream(System.out);
		ps2.println("Java Language.");
		ps2.print("C/");
		ps2.println("C++ Application.");
		ps2.println("Python Application.");
		ps2.close();
		}catch(Exception ee)
			{
			}
		}
	}

		