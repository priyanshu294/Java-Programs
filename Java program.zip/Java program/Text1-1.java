class Text1
	{
	public Text1(String s)
		{
		System.out.println("Hi");
		}
	void Text1()
		{
		System.out.println("Java Technocrat.");
		}
	public static void main(String args[])
		{
Text1 tt=new Text1();//non parameterized 
		tt.Text1();
		}
	Text1()
		{
		System.out.println("Object is Constructed.");
		}
	}


		