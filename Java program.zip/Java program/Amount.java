package amount;
public class Amount
{
public int presentamount;
public int showAmount(int a)
{
presentamount=a;
return presentamount;
}
}
