import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class Mouse1 extends Applet implements MouseMotionListener
	{
	int x,y;
	String msg;
	public void init()
		{
		setBackground(Color.black);
		addMouseMotionListener(this);
		}
	public void mouseMoved(MouseEvent me)
		{
		
		}
	public void mouseDragged(MouseEvent me)
		{
		x=me.getX();
		y=me.getY();
		repaint();	
		}
	public void paint(Graphics g)
		{
		g.setColor(Color.white);
		g.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,23));
		msg="Java Technocrat ";
		g.drawString(msg,x,y);
		}
	}
/*
<applet code="Mouse1" width="400" height="500">
</applet>
*/
		 