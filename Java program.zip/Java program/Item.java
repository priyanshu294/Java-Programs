import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class Item extends Applet implements ItemListener
	{
	Checkbox cb1,cb2,cb3;
	CheckboxGroup cbg;
	String msg;
	Font f;
	public void init()
		{
		f=new Font("Arial",Font.BOLD,23);
		cbg=new CheckboxGroup();
		cb1=new Checkbox("Java",cbg,true);
		cb2=new Checkbox("Python",cbg,false);
		cb3=new Checkbox(".Net",cbg,false);
		
		cb1.setFont(f);
		cb2.setFont(f);
		cb3.setFont(f);
		cb1.addItemListener(this);
		cb2.addItemListener(this);
		cb3.addItemListener(this);
		
		add(cb1);
		add(cb2);
		add(cb3);
		}
	@Override
	public void itemStateChanged(ItemEvent ie)
		{
		repaint();
		}
	public void paint(Graphics g)
		{
		g.setColor(Color.blue);
	g.setFont(new Font("Verdana",Font.BOLD,29));	
		msg="Selected Language is ";
		Checkbox cb=cbg.getSelectedCheckbox();
		String label=cb.getLabel();
		msg+=label;
		g.drawString(msg,40,200);
		}
	}
/*
<applet code="Item" width="500" height="400"></applet>
*/
		
		
			
		
		
	