import java.util.*;
import java.io.*;
public class Demo2
	{
	public static void main(String args[])throws Exception
		{
	File f=new File("E:/p1/Demo.class");
	System.out.println(f.canRead());
	System.out.println(f.canWrite());
	System.out.println(f.isDirectory());
	System.out.println(f.isFile());
	System.out.println(f.isAbsolute());
System.out.println(new Date(f.lastModified()));
System.out.println(f.length());
System.out.println(f.exists());
System.out.println(f.isDirectory());
System.out.println(f.getParent());
System.out.println(f.getPath());
System.out.println(f.getName());
System.out.println(f.canExecute());

File ff=new File("E:/p1/JTian.java");
f.renameTo(ff);
		}
	}
	
	
	
	
	