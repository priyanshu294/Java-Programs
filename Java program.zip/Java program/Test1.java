public class Test1
	{
	public static void main(String args[])
	{
	int i=0,j=9;
	do{
	i++;
	if(i++>j--)
		{
		break;
		}
	}while(i++<=5);
	System.out.println(i+"\t"+j);
	}
	}
	
	