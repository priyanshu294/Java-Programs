import java.util.*;

public class Palin
	{
	public static void main(String argsp[])
		{
		Scanner s=new Scanner(System.in);
System.out.println("Enter Something to reverse");
		String text=s.nextLine();
	
		String rev="";
		for(int i=text.length()-1;i>=0;i--)
			{
			rev=rev+text.charAt(i);
			}
	System.out.println("Reverse is "+rev);
	if(text.equalsIgnoreCase(rev))
		{
	System.out.println("Its  a Palindrome");
		}else{
	System.out.println("Its NOT a Palindrome");
		}
	
		}
	}