class Base
	{
	public static void displayMessage(String s)
		{
		System.out.println("base class message is : "+s);
		}
	}
class Sub extends Base
	{
	public void displayMessage(String m)
		{
		System.out.println("Sub class message is : "+m);
		}
	}
public class Demo2
	{
	public static void main(String args[])
		{
		Sub s=new Sub();
		s.displayMessage("I like Java");
		}
	}
