import java.util.*;

public class Demo7
	{
	public static void main(String args[])
		{
		Runtime rr=Runtime.getRuntime();
		Scanner ss=new Scanner(System.in);
System.out.println("enter path of Application");
		String s[]=new String[2];
		s[0]=ss.nextLine();
	
System.out.println("enter path of File");
		s[1]=ss.nextLine();
		
	try{
	Process p=rr.exec(s);
	}catch(Exception ee)
		{}
	}
	}	