public class Text4
	{
	public void add(int a,int b)
		{
		System.out.println("Addition is : "+(a+b));
		}
	void add(short s1,short s2)
		{
		System.out.println("Sum is : "+(s1+s2));
		}
	void add(String s1,String s2)
		{
		System.out.println("Message is : "+(s1+s2));
		}
	public static void main(String args[])
		{
		Text4 tt=new Text4();
		byte b1=10,c1=20;
		tt.add(b1,c1);
		tt.add("I Like ","Java");
		}
	}
