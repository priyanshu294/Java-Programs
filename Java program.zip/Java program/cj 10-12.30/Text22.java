public class Text22
	{
	public static void main(String args[])
		{
		for(int i=0;i<=4;i++)
			{
			switch(i)
				{
				case 1:
				System.out.print("A");
				
				case 2:
				System.out.print("B");
				break;

				default:
				System.out.print("C");

				case 3:
				System.out.print("D");
			
				case 4:
				System.out.print("E");
				break;
				}
			}
		}
	}
