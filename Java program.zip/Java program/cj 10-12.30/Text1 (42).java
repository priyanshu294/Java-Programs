public class Text1
	{
	int data;
	Text1(int data)
		{
		this.data=data;
		}
	@Override
	public String toString()
		{
		return Integer.toString(data);
		}
	public static void main(String args[])
		{
		Text1 tt=new Text1(100);
		System.out.println(tt);
		}
	}

