enum Day
	{
	Mon,Tue,Wed;
	}
public class Demo1
	{
	public static void main(String args[])
		{
		Day d=Day.Mon;
		
	switch(d)
		{
		case Mon:
		System.out.println("Hello");
		
		case Tue:
		System.out.println("BBSR");
		
		case Wed:
		System.out.println("CTC");
		break;

		default:
		System.out.println("Java");
		}
	}
	}
		
		
		