import app1.*;

public class Main2 extends Address
	{
	public static void main(String args[])
		{
		Main2 mm=new Main2();
		mm.setAddress("m/92, BBSR");
		System.out.println("Address is "+mm.getAddress());
		}
	}
	