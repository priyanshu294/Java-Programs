class Mammal
	{
	public void eat(Mammal m)
		{
		System.out.println("Mammal is eating.");
		}
	}
class Horse extends Mammal
	{
	public void eat(Horse h)
		{
		System.out.println("Horse is eating.");
		}
	}
class Cattle extends Horse
	{
	public void eat(Cattle c)	
		{
		System.out.println("Cattle is eating.");
		}
	}
public class Test2
	{
	public static void main(String args[])
		{
		Mammal m=new Horse();
		Horse h=new Cattle();
		h.eat(m);
		h.eat((Horse)m);
		}
	}
