public class Text20
	{
	public static void main(String args[])
		{
		int i=70;
		switch(i)
			{
			case 'A':
			System.out.println("A");
			break;

			case 'A'+5:
			System.out.println("B");
			break;

			case 'A'+10:
			System.out.println("C");
			break;

			default:
			System.out.println("D");
			break;
			}
		}
	}
