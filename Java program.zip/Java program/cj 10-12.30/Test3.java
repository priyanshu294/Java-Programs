class Mammal
	{
	public void eat(Mammal m)
		{
		System.out.println("Mammal is eating.");
		}
	}
class Horse extends Mammal
	{
	public void eat(Mammal h)
		{
		System.out.println("Horse is eating.");
		}
	}
class Cattle extends Horse
	{
	public void eat(Mammal c)	
		{
		System.out.println("Cattle is eating.");
		}
	}
public class Test3
	{
	public static void main(String args[])
		{
		Mammal m=new Horse();
		Horse h=new Cattle();
		h.eat(m);
		}
	}
