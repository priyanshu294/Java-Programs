public class Text19
	{
	public static void main(String args[])
		{
		long l=10;
		switch((int)l)
			{
			case 1:
				System.out.println("A");
				break;

			case 10:
				System.out.println("B");
				break;

			default:
				System.out.println("C")	;
				break;
			}
		}
	}
