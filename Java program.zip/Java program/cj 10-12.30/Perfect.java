import java.util.Scanner;
public class Perfect
{
	public static void main(String args[])
	{
		Scanner ss=new Scanner(System.in);
		System.out.println("Enter a number");
		int n=ss.nextInt();
		int c=0;
		for(int i=1;i<n;i++)
		{
			if(n%i==0)
			{
				c=c+i;
			}
		}
		if(c==n)
		System.out.println("Perfect number");
		else
		System.out.println("Not a perfect number");
	}
}