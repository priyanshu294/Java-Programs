#include<stdio.h>
#include"jni.h"
#include"Arm.h"
JNIEXPORT jboolean JNICALL Java_Arm_check(JNIEnv *p,jobject obj,jint num)
	{
	int a=num;
	int b,sum=0;
	while(a>0)	
		{
		b=a%10;
		sum+=(b*b*b);
		a/=10;
		}
	if(num==sum)	
		{
		return 1;
		}else{
		return 0;
		}
	}
