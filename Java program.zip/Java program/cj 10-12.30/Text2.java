class X
	{
	public void showMessage(String msg)
		{
		System.out.println("Base class Message is : "+msg);
		}
	}
class Y extends X
	{
	@Override
	public void showMessage(String s)
		{
		System.out.println("Child class Message is : "+s);
		}
	}
public class Text2
	{
	public static void main(String args[])
		{
		Y ab=new Y();
		ab.showMessage("I LIke Java")	;
		}
	}

		
	