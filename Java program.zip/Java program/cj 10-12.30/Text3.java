class X
	{
	String name;
	public Object getName(String name)
		{
		this.name=name;
		return name;
		}
	}
class Y extends X
	{
	@Override
	public String getName(String s)
		{
		name=s;
		return name;
		}
	}
public class Text3
	{
	public static void main(String args[])
		{
		Y aa=new Y();
		String name=aa.getName("Java Technocrat.");
		System.out.println("Name is : "+name);
		}
	}

		
	
