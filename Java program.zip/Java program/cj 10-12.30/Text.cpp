using namespace std;
#include<iostream>
#include"jni.h"
#include"Text.h"
JNIEXPORT void JNICALL Java_Text_call(JNIEnv *a,jobject obj)
	{
	cout<<"I am in C++ Application."<<endl;
	}
		