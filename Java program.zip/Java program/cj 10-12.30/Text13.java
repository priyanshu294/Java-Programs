public class Text13
	{
	public static void main(String args[])
		{
		short s1=10;
		short s2=20;
		short s=(short)(s1%s2);
		System.out.println(s);
		}
	}
