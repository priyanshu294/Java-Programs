public class Text1
	{
	public static void main(String args[])
		{
		Text1 tt=new Text1();
		Text1 aa=new Text1();
		System.out.println(tt.hashCode()+"\t"+aa.hashCode())	;
		if(tt.equals(aa))
			{
			System.out.println("True");
			}else{
			System.out.println("False");
			}
		Text1 kk=aa;
		System.out.println(aa.hashCode()+"\t"+kk.hashCode());
		if(kk.equals(aa))	
			{
			System.out.println("True");
			}else{
			System.out.println("False");
			}
		}
	}

