import java.util.*;
public class Palin1
	{
	public static void main(String args[])
		{
		Scanner ss=new Scanner(System.in);
		System.out.println("Enter Somthing");
		String txt=ss.nextLine();
		StringBuffer sb=new StringBuffer(txt);
		sb.reverse();
		String rev=sb.toString();
		
		if(txt.equalsIgnoreCase(rev))
			{
	System.out.println("Its a Palindrome");
			}else{
	System.out.println("Its NOT a Palindrome");
			}
		}
	}