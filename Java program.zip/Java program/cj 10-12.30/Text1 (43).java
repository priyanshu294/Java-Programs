public class Text1
	{
	public static void main(String args[])
		{
		System.out.println('A'+10+"Java");
		System.out.println("Java"+'A'+10);
		System.out.println('A'+'A'+"Java"+'A'+'A');
		System.out.println('A'+"Java"+'A');
		}
	}
