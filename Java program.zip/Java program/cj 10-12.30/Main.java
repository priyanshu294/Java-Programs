import c1.*;
import c2.*;

public class Main
	{
	public static void main(String args[])
		{
		Demo1 dd=new Demo1();
		dd.setName("Java");
		Test1 tt=new Test1();
		tt.setRoll(121);
		
	System.out.println("Name is "+dd.getName()+" Roll is "+tt.getRoll());
		}
	}
		