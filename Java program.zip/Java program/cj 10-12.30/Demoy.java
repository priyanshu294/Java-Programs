public class Demoy
	{
	public static void main(String...args7)
		{
		add();
		add(12);
		add(12,11,22);
		add(33,44,11,2,3,4,5,5);
		}
	public static void add(int...x)
		{
		int sum=0;
		for(int a:x)
			{
			sum+=a;
			}
		System.out.println("Addition "+sum);
		}
	}
		
		