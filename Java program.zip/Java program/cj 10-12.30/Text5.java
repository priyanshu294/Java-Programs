public class Text5
	{
	void call(String s)
		{
		System.out.println("String class.");
		}
	void call(Object obj)
		{
		System.out.println("Object class.");
		}
	public static void main(String args[])
		{
		Text5 tt=new Text5();
		tt.call(null);
		}
	}
