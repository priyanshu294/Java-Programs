public class Text1
	{
	int arr[];
	void display()
		{
		arr=new int[]{12,78,34,66,99};
		for(int a : arr)
			{
			System.out.println(a);
			}
		}
	public static void main(String args[])
		{
		Text1 tt=new Text1();
		tt.display();
		}
	}



