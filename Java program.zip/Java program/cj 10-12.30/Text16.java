public class Text16
	{
	int data;
	public static void main(String args[])
		{
		Text16 tt=new Text16();
		tt.data+=5;
		
		Text16 aa=new Text16();
		aa.data++;

		tt=aa;
		tt.data++;
		aa.data++;
		System.out.println(tt.data+"\t"+aa.data);
		}
	}
