import java.util.Scanner;
public class Sort
	{
	public static void main(String args[])
		{
		Scanner ss=new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int size=ss.nextInt();
		int arr[]=new int[size];
		System.out.println("Enter the elements.");
		for(int i=0;i<size;i++)
			{
			arr[i]=ss.nextInt();
			}
		System.out.println("\nSEe the elements before sorting.\n")	;
		for(int r : arr)	
			{
			System.out.println(r);
			}
		System.out.println("Sort the elements of the array.");
		for(int i=0;i<(size-1);i++)					{
			for(int j=0;j<size-i-1;j++)
				{
				if(arr[j]>arr[j+1])
					{
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
					}
				}
			}
		System.out.println("\nSee the elements.\n");
		for(int aa : arr)	
			{
			System.out.println(aa);
			}
		}
	}

				