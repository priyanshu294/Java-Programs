enum Month
	{
	Jan,Feb,Mar;
	}
public class Demo
	{
	public static void main(String args[])
		{
		Month m=Month.Jan;
		System.out.println(m);
		}
	}
	
