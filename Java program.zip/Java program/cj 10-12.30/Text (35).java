import java.io.*;
class Stud
	{
	String name;
	int roll;
	double fee;
	}
public class Text
	{
	public static void main(String args[])	throws IOException
		{
		DataInputStream dis=new DataInputStream(System.in);
		System.out.println("Enter the size of students");
		int size=Integer.parseInt(dis.readLine());
		Stud ss[]=new Stud[size];
		System.out.println("Enter info of each students.");
		for(int i=0;i<size;i++)
			{
			ss[i]=new Stud();
			System.out.println("Enter name");
			ss[i].name=dis.readLine();
			System.out.println("Enter roll number.");
			ss[i].roll=Integer.parseInt(dis.readLine());
			System.out.println("Enter fee");
			ss[i].fee=Double.parseDouble(dis.readLine());
			}
		System.out.println("\nSee the data.\n");
		for(Stud aa : ss)
			{
			System.out.println("Name is : "+aa.name+"  Roll number is : "+aa.roll+"  Fee is : "+aa.fee);
			}
		}
	}

		