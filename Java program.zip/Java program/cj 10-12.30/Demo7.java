interface A
	{
	void m1();
	}
public class Demo7
	{
	public static void main(String args[])
		{
		A ab=new A()
			{
			@Override
			public void m1()
				{
		System.out.println("I am in m1");
				}
			};

		ab.m1();
		}
	}
	
			