import java.util.Scanner;
public class In
	{
	public static void main(String args[])
		{
		Scanner ss=new Scanner(System.in);
		System.out.println("Enter number of rows");
		int r=ss.nextInt();
		System.out.println("Enter number of columns");
		int c=ss.nextInt();
		int arr[][]=new int[r][c];
		for(int i=0;i<r;i++)
			{
			for(int j=0;j<c;j++)
				{
				arr[i][j]=ss.nextInt();
				}
			}
		System.out.println("\nSee the array elements.\n");
		for(int i=0;i<r;i++)
			{
			for(int j=0;j<c;j++)
				{
				System.out.print(arr[i][j]+"\t");
				}
			System.out.println("\n");
			}
		}
	}

