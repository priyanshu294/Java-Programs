public class Text3
	{
	public static void main(String args[])
		{
		String s1=new String("java");
		String s2="java";
		if(s1==s2)
			{
			System.out.println("True");
			}else{
			System.out.println("False");
			}
		if(s1.equals(s2))
			{
			System.out.println("True");
			}else{
			System.out.println("False");
			}

		System.out.println(s1.hashCode()+"\t"+s2.hashCode());

		String s3="JAVA";
		if(s2==s3)
			{
			System.out.println("True");
			}else{
			System.out.println("False");
			}
		if(s2.equals(s3))	
			{
			System.out.println("True");
			}else{
			System.out.println("False");
			}
		if(s2.equalsIgnoreCase(s3))
			{
			System.out.println("True");
			}else{
			System.out.println("False");
			}
		System.out.println(s2.hashCode()+"\t"+s3.hashCode());
		
		byte bb[]=s3.getBytes();
		System.out.println("\nSee the contents.\n");
		for(byte b : bb)
			{
			System.out.print(b+"\t");
			}
		
		char cc[]=s3.toCharArray();
		System.out.println("\nSee the Contents.\n");
		for(char k : cc)
			{
			System.out.print(k+"\t");
			}
		
		String kk="I Like Java Technocrat.";
		String gg[]=kk.split(" ");
		System.out.println("\nSee the content.\n");
		for(String g : gg)
			{
			System.out.print(g+"\t");
			}
		}
	}

			
	