public class Text3
	{
	int data;
	Text3(int data)
		{
		this.data=data;
		}
	/*
	@Override
	public String toString()		
		{
		return String.valueOf(data);
		}*/
	public static void main(String args[])
		{
		Text3 tt=new Text3(12000);
		System.out.println(tt);
		Text3 aa=new Text3(15000);
		System.out.println(aa);
		}
	}

		