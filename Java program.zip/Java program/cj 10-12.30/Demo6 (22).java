public class Demo6
	{
	public static void main(String args[])
		{
		Runtime rr=Runtime.getRuntime();
		
		try{
		Process p=rr.exec("C:/Program Files/VideoLAN/VLC/vlc.exe");
		}catch(Exception ee)
			{}
		}
	}