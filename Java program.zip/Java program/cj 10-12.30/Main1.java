import pa2.Name;
import pa2.Roll;
import pa3.Address;

public class Main1
	{
	public static void main(String args[])
		{
		Name n=new Name();
		Roll r=new Roll();
		Address a=new Address();
		
		System.out.println("Name is "+n.getName()+" Roll is "+r.getRoll()+" Address is "+a.getAddress());
		}
	}
