import java.io.*;
public class Input1
	{
	public static void main(String args[])throws IOException
		{
		DataInputStream dis=new DataInputStream(System.in);
		System.out.println("Enter the size of the array.");
		int size=Integer.parseInt(dis.readLine());
		String str[]=new String[size];
		System.out.println("Enter the name");
		for(int i=0;i<size;i++)
			{
			str[i]=dis.readLine();
			}
		System.out.println("\nSee the elements of the array.\n");
		for(String s : str)
			{
			System.out.println(s);
			}
		}
	}
