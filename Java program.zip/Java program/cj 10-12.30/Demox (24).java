import java.applet.*;

public class Demox extends Applet
	{
	public Demox()
		{
	System.out.println("Object is Constructed");
		}
	
	public void start()
		{
	System.out.println("Object is started");
		}
	public void init()
		{
	System.out.println("Object is Initialized");
		}
	public void destroy()
		{
System.out.println("Applet is Finalized\nBye Byee");
		}
	public void stop()
		{
	System.out.println("Applet is Stopped");
		}
	}
/*
<applet code="Demox" width="500" height="400"></applet>
*/