public class Text9
	{
	public static void main(String args[])
		{
		int i=257;
		byte b=(byte)i;
		System.out.println(b);
		}
	}
