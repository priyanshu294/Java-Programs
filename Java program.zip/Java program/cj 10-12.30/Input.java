import java.io.*;
public class Input
	{
	@Deprecated
	public static void main(String args[])throws IOException
		{
		DataInputStream dis=new DataInputStream(System.in);
		System.out.println("Enter your name");
		String name=dis.readLine();
		System.out.println("Name is : "+name);
		}
	}

		