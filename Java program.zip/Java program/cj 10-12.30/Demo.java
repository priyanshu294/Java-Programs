class X
	{
	int data;
	void call()
		{
		System.out.println("I am in base class.");
		}
	public void increment()
		{
		data++;
		}
	}
class Y extends X
	{
	void show()
		{
		System.out.println("I am in Sub class.");
		}
	@Override
	public void increment()
		{
		data+=10;
		}
	}
public class Demo
	{
	public static void main(String args[])
		{
		X aa=new Y();
		aa.call();
		aa.show();
		aa.increment();	
		System.out.println("data value is : "+aa.data);
		}
	}
