interface Animal
	{
	public void eat();
	void sleep();
	}
class Lion implements Animal
	{
	@Override
	public void eat()
		{
	System.out.println("I eat Meat");
		}
	@Override
	public void sleep()
		{
	System.out.println("I sleep in the cave");
		}
	}
class Rabbit implements Animal
	{
	@Override
	public void sleep()
		{
	System.out.println("I sleep in the busses");
		}
	@Override
	public void eat()
		{
	System.out.println("I eat Carrot");
		}
	}
class Zoo
	{
	public static void sendAnimal(Animal aa)
		{
		aa.eat();
		aa.sleep();
		}
	}
public class Demo3
	{
	public static void main(String args[])
		{
		Lion ll=new Lion();
		Rabbit rr=new Rabbit();
		
		Zoo.sendAnimal(ll);
		Zoo.sendAnimal(rr);	
		}
	}
