public class Text15
	{
	public static void main(String args[])
		{
		int a,b,c,d;
		a=b=c=d=10;
		a+=b-=c*=d/=5;
		System.out.println(a+"\t"+b+"\t"+c+"\t"+d);
		}
	}

		