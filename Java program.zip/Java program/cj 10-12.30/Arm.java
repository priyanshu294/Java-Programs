import java.util.Scanner;
public class Arm
	{
	public native boolean check(int num);
	public static void main(String args[])
		{
		Arm aa=new Arm();
		Scanner ss=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=ss.nextInt();
		boolean b=aa.check(num);
		if(b==true)
			{
			System.out.println(num+" is an armstrong number.");
			}else{
			System.out.println(num+" is not an armstrong number.");
			}
		}
	static{
	System.loadLibrary("S");//S.lib   S.c
	}
	}

		