import java.util.Scanner;
public class Super 
{
	public static void main(String args[])
	{
		Scanner ss=new Scanner(System.in);
		System.out.println("Enter a number");
		int no=ss.nextInt();
		int rem,sum=0;
		while(no>=10)
		{
			sum=0;
			while(no>0)
			{
				rem=no%10;
				sum=sum+rem;
				no=no/10;
			}
			no=sum;
		}
	System.out.println("Super digit : "+sum);
	}
}