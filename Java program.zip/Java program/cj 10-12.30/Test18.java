public class Test18
	{
	public static void main(String args[])
		{
		int i=10;
		int x=(int)((i==10)? 10 : 1.0);
		System.out.println(x);
		}
	}
