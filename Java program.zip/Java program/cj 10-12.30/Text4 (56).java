public class Text4
	{
	public static void main(String args[])
		{
		int a=5;
		int b=a++ + a++ + ++a + a-- + a-- + a++;
		System.out.println(a+"\t"+b);
		}
	}
