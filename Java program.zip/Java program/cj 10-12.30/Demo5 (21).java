public class Demo5
	{
	public static void main(String args[])
		{
		Runtime rr=Runtime.getRuntime();
		
System.out.println("Total Memory of JVM is "+rr.totalMemory());

System.out.println("Available Memory of JVM is "+rr.freeMemory());
		}
	}
		