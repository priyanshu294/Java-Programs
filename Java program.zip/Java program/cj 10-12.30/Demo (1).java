import static java.lang.Math.*;
import static java.lang.System.*;
import static java.lang.Integer.*;

public class Demo
	{
	public static void main(String args[])
		{
		out.println(pow(2,4));
		out.println("I am in JT");
		String s="123";
		int a=parseInt(s);
	
		out.print(a);
		}
	}		
 