package c2;

import java.util.*;

public class Roll extends c1.Name
	{
	public int roll;
	public void setRoll()
		{
	System.out.println("Enter ur Roll No.");
		roll=new Scanner(System.in).nextInt();
		}
	public int getRoll()
		{
		return roll;
		}
	}
 
		