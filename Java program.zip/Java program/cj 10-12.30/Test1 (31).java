public class Test1
	{
	public static void main(String args[])
		{
		int arr[][];
		arr=new int[1][];
		System.out.println(arr[0]);
		}
	}
