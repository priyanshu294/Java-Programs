import java.util.*;
public class Prime
{
	public static void main(String args[])
	{
		Scanner ss=new Scanner(System.in);
		System.out.println("Enter last number");
		int n=ss.nextInt();
		int sum=0,count=0;
		for(int i=1;i<n;i++)
		{
			for(int j=1;j<=i;j++)
			{
				if(i%j==0)
				{
				sum++;
				}
			}
			if(sum==2)
			{
				System.out.print(i+" ");
				count++;
			}
			sum=0;

		}
		System.out.println("\nThere are "+count+" prime number is present");
	}
}