public abstract class Text
	{
	String name;
	int roll;
	Text()
		{
		System.out.println("Object is Constructed.");
		}
	void call()
		{
		System.out.println("Annonymous inner class.")	;
		}
	public abstract void setName(String name);
	public abstract String getName();
	public abstract void setRoll(int roll)	;
	public abstract int getRoll();
	public static void main(String args[])
		{
		Text tt=new Text()//Annonymous Inner
			{
			@Override
			public void setName(String s)
				{
				name=s;
				}
			@Override
			public String getName()
				{
				return name;
				}
			@Override
			public void setRoll(int r)
				{
				roll=r;
				}
			@Override
			public int getRoll()						{
				return roll;
				}
			};
		tt.setName("Java");
		System.out.println("Name is : "+tt.getName());
		tt.setRoll(1)	;
		System.out.println("Roll number is : "+tt.getRoll());
		tt.call();
		}
	}
