package c1;
import java.util.*;
public class Name
	{
	public String name;
	public void setName()
		{
	System.out.println("Enter ur Name");
	name=new Scanner(System.in).nextLine();
		}
	public String getName()
		{
		return name;
		}
	}