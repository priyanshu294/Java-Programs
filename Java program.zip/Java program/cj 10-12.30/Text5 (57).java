public class Text5
	{
	public static void main(String args[])
		{
		String s1=new String("Java");
		Class cc=s1.getClass();
		System.out.println("Name of the class is : "+cc.getName());
		}
	}
