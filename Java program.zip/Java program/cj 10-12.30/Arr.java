import java.util.*;

public class Arr
	{
	public static void main(String args[])
		{
		int arr[];
		Scanner ss=new Scanner(System.in);
		System.out.println("Enter the size");
		int size=ss.nextInt();
		arr=new int[size];
		
	System.out.println("Enter "+size+" Numbers");

		for(int i=0;i<size;i++)
			{
			arr[i]=ss.nextInt();
			}
	System.out.println("\nSee the elements\n");
		for(int i=0;i<size;i++)
			{
			System.out.print(arr[i]+" ");
			}
	int sm=arr[0];
	int lr=arr[0];
	
	for(int i=1;i<size;i++)
		{
		if(arr[i]>lr)
			{
			lr=arr[i];
			}
		else if(arr[i]<sm)
			{
			sm=arr[i];
			}
		}
	System.out.println("\nLargest number is "+lr);
	System.out.println("Smallest number is "+sm);
	}
	}
	
		 