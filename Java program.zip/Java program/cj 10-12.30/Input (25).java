import java.util.Scanner;
public class Input
	{
	public static void main(String args[])
		{
		Scanner ss=new Scanner(System.in);
		System.out.println("Enter the size of the array.");
		int size=ss.nextInt();
		String str[]=new String[size];
		System.out.println("Enter the name");
		for(int i=0;i<size;i++)
			{
			str[i]=ss.nextLine();
			}
		System.out.println("\nSee the elements of the array.\n");
		for(String s : str)
			{
			System.out.println(s);
			}
		}
	}
