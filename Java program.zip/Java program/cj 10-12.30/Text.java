class A
	{
	public static void main(String args[])
		{
		System.out.println("Main method of A class.");
		}
	}
class Text extends A
	{
	
	public static void main(String as[])
		{
		System.out.println("Main method of Text class.");
		}
	}

	