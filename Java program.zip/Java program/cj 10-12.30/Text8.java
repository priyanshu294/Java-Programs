public class Text8
	{
	public static void main(String args[])
		{
		byte b=12;
		int i=b;
		long l=i;
		float f=l;
		System.out.println(i+"\t"+l+"\t"+f);
		
		double d1=12.99;
		float f1=(float)d1;
		long l1=(long)f1;
		int i1=(int)l1;
		byte b1=(byte)i1;
		System.out.println(b1+"\t"+i1+"\t"+l1+"\t"+f1);
		}
	}

		