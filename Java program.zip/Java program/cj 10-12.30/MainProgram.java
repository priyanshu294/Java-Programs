import c2.*;

public class MainProgram
	{
	public static void main(String args[])
		{
		Roll rr=new Roll();
		rr.setName();
		rr.setRoll();
	System.out.println("Name is "+rr.getName()+"\tRoll is "+rr.getRoll());
		}
	}