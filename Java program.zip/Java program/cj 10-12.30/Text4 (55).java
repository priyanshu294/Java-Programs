public class Text4
	{
	@Override
	public void finalize()
		{
		System.out.println("My job is over.");
		}
	Text4()		
		{
		System.out.println("Object is Constructed.");
		}
	void call()
		{
		System.out.println("My life is colorful.");
		}
	static void display()
		{
		Text4 tt=new Text4();
		tt.call();
		tt.call();
		tt=null;
		
		Text4 aa=new Text4();
		aa.call();
		aa=null;
		}
	public static void main(String args[])		
		{
		display();
		System.gc();
		try{
		Thread.sleep(2000);
		}catch(Exception ee)
			{
			}
		}
	}
