public class Demo4
	{
	public static void main(String args[])
		{
		int i=1;
System.out.println(System.currentTimeMillis());
	
		while(true)
			{
			System.out.println(i++);
			if(i==100)
			System.exit(0);
			}
		}
	}