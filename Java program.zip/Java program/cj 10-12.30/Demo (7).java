public class Demo
	{
	String name;
	int roll;
	public void setName(String name)
		{
		this.name=name;
		}
	public String getName()
		{
		return name;
		}
	public void setRoll(int roll)
		{
		this.roll=roll;
		}
	public int getRoll()
		{
		return roll;
		}
	}

		