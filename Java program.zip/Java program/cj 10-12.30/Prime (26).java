import java.io.*;
public class Prime
{
	public static void main(String nargs[])throws IOException
	{
		DataInputStream ds=new DataInputStream(System.in);
		System.out.println("Enter a no");
		int no=Integer.parseInt(ds.readLine());
		int c=0;
		for(int i=1;i<=no;i++)
		{
			if(no%i==0)
			{
			c++;
			}
		}
		if(c==2)
		{
			System.out.println(no+" is a prime number");
		}
		else
		{
		System.out.println(no+" is NOT a prime number");
		}
		
	}
}