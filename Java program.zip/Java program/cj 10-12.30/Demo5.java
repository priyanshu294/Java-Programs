interface X
	{
	void show();
	void display()
		{
		System.out.println("I am in display");
		}
	}
public class Demo5 implements X
	{
	public static void main(String args[])
		{
		Demo5 dd=new Demo5();
		dd.show();
		X.display();
		}
	public void show()
		{
		System.out.println("I am in show");
		}
	}