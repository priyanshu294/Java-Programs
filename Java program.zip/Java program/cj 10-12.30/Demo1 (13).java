public class Demo1
	{
	private void cube(int n)
		{
		System.out.println("Cube of "+n+" is : "+(n*n*n));
		}
	}
