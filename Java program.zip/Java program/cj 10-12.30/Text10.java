public class Text10
	{
	public static void main(String args[])
		{
		final int i=12;
		byte b=i;
		System.out.println(b);
		}
	}
