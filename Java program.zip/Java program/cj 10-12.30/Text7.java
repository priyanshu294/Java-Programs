public class Text7
	{
	public static void main(String args[])
		{
		boolean b=false;
		if(b)
			{
			System.out.println("A");
			}
		else if(!b)
			{
			System.out.println("B");
			}else{
			System.out.println("C");
			}
		}
	}
	