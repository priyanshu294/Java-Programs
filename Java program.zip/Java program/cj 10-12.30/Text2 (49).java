public class Text2
	{
	public static void main(String args[])
		{
		String s1=new String("abc");
		String s2="abc";
		String s3="ABC";
		String s4="abc";
		String s5=new String("abc");
		if(s1==s2)
			{
			System.out.println("True");
			}else{
			System.out.println("False");
			}
		if(s2==s3)
			{
			System.out.println("True");
			}else{
			System.out.println("False");
			}
		if(s2==s4)
			{
			System.out.println("True");
			}else{
			System.out.println("False");
			}
		if(s1==s5)
			{
			System.out.println("True");
			}else{
			System.out.println("False");
			}
		}
	}
