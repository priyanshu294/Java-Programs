import java.util.Scanner;
public class Fact
{
	public static void main(String args[])
	{
		Scanner ss=new Scanner(System.in);
		System.out.println("Enter the no");
		int no=ss.nextInt();
		int f=1;
		while(no>0)
		{
			f=f*no;;
			no--;
		}
		System.out.println("Fact is : "+f);
	}
}