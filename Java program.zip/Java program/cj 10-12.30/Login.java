import java.io.*;
import java.sql.*;
import javax.servlet.*;
public class Login extends GenericServlet
	{
	Connection cn;
	PreparedStatement ps;
	@Override
	public void init()
		{
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","manager");
		ps=cn.prepareStatement("select * from login where name=(?) and password=(?)");
		}catch(Exception ee)
			{
			ee.printStackTrace();
			}
		}
	@Override
	public void service(ServletRequest req,ServletResponse res)throws IOException,ServletException
		{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		String s1=req.getParameter("name");
		String s2=req.getParameter("pass");
		//ServletResponse interface
//public abstract void setContentType(String type);
//public abstract PrintWriter getWriter();
		//ServletRequest interface
//public abstract String getParameter(String name);
		try{
		ps.setString(1,s1);
		ps.setString(1,s2);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
			{
			out.println("<html><body bgcolor='cyan'><font color='red' size='5'><center>");
			out.println("<b>Welcome To Java Technocrat.</b><br>")	;
			out.println("<b>U are an authorized user.</b>");
			out.println("</center></font></body></html>");
			}else{
			out.println("<html><body bgcolor='yellow'><font color='black' size='5'><center>");
			out.println("<b>U are not an authorised user.</b><br>");
			out.println("<b>Check Username and password.</b>");
			out.println("</font></center></body></html>");
			}
		}catch(Exception ee)
			{
			ee.printStackTrace();
			}
		}
	@Override
	public void destroy()
		{
		try{
		ps.close();
		cn.close();
		}catch(Exception ee)
			{
			ee.printStackTrace();
			}
		}
	}

		
			

		
	