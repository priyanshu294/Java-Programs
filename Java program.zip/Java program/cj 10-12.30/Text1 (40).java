abstract class X
	{
	int data;
	public abstract void setData(int data);
	public abstract int getData();
	}
public class Text1
	{
	public static void main(String args[])
		{
		X ab=new X()
			{
			@Override
			public void setData(int x)
				{
				data=x;
				}
			@Override
			public int getData()
				{
				return data;
				}
			};
		ab.setData(100);
		System.out.println("Data value is : "+ab.getData())	;
		}
	}


	