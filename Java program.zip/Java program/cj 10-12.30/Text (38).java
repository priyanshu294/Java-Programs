public class Text
	{
	int data;
	Text(int data)
		{
		this.data=data;
		}
	@Override
	public int hashCode()
		{
		return data;
		}
	@Override
	public boolean equals(Object obj)	
		{
		if(this.hashCode()==obj.hashCode())
			{
			return true;
			}else{
			return false;
			}
		}
	public static void main(String args[])
		{
		Text tt=new Text(100);
		Text aa=new Text(100);
		System.out.println(tt.hashCode()+"\t"+aa.hashCode());
		if(tt.equals(aa))
			{
			System.out.println("True");
			}else{
			System.out.println("False");
			}
		Text ss=new Text(99);
		System.out.println(tt.hashCode()+"\t"+ss.hashCode());
		if(ss.equals(tt))
			{
			System.out.println("True");
			}else{
			System.out.println("False");
			}
		}
	}
