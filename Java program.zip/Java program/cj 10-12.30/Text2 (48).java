public class Text2
	{
	int data;
	public void setData(int data)
		{
		this.data=data;
		System.out.println(this);//toString()
		}
	@Override
	public String toString()
		{
		return Integer.toString(data);
		}
	public static void main(String args[])
		{
		Text2 tt=new Text2();
		tt.setData(100);
		System.out.println(tt);
		}
	}


	