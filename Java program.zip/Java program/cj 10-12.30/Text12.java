public class Text12
	{
	public static void main(String args[])
		{
		final long l=12;
		int i=l;
		System.out.println(i);
		}
	}
