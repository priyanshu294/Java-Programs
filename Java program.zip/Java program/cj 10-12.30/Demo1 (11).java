import java.util.Scanner;
public class Demo1
	{
	public static void main(String args[])
		{
		Scanner ss=new Scanner(System.in);
		System.out.println("Enter class name");
		String d=ss.nextLine();
		try{
		Class aa=Class.forName(d);
		String name=aa.getName();
		System.out.println("Class name : "+name);
		}catch(ClassNotFoundException ce)	
			{
			System.out.println("Class Not Found.");
			}
		}
	}
