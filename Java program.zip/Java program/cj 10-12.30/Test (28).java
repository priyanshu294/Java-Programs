public class Test
	{
	private Test()
		{
		System.out.println("Object is Constructed.");
		}
	private int data;
	//accessor method
	public void setData(int d)
		{
		data=d;
		}
	public int getData()
		{
		return data;
		}
	//static factory method
	public static Test getObject()
		{
		return new Test();
		}
	}
		