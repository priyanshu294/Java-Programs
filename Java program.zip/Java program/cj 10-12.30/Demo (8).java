public class Demo
	{
	private void getData()
		{
		System.out.println("I am in Java Technocrat.");
		}
	}
