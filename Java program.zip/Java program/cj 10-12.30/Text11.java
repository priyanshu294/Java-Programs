public class Text11
	{
	public static void main(String args[])
		{
		final int i=129;
		byte b=(byte)i;
		System.out.println(b);
		}
	}
