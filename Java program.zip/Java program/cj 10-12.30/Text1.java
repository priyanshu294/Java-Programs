class Base
	{
	int data;
	Base()
		{
		increment();
		}
	void increment()
		{
		data++;
		}
	}
class Sub extends Base
	{
	Sub()
		{
		increment();
		}
	protected void increment()
		{
		data+=10;
		}
	}
public class Text1	
	{
	public static void main(String args[])		
		{
		Sub ss=new Sub();
		ss.increment();
		System.out.println("data value is : "+ss.data);
		}
	}
	
		