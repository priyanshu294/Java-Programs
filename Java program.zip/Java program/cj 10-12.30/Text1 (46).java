public class Text1
	{
	public static void main(String args[])
		{
		System.out.println(-(-5));
		System.out.println(+(-5));
		}
	}
