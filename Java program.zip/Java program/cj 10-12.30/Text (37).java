public class Text
	{
	public static void main(String args[])
		{
		String s="This is a demo of java program.";
		int size=s.length();
		System.out.println("Size is : "+size);
		
		char ch=s.charAt(s.indexOf('j'));
		System.out.println("Extracted char is : "+ch);

		int start=s.indexOf('j');//18
		int end=s.length();//31
		char cc[]=new char[end-start];
		s.getChars(start,end,cc,0);
		System.out.println(cc);
		
		String s1=s.toUpperCase();
		System.out.println(s);
		System.out.println(s1);
		
		String s2=s1.toLowerCase();
		System.out.println(s2);
		System.out.println(s1);

		String s3=s.replace('a','R');
		System.out.println(s3);

		if((s.startsWith("This"))&&(s.endsWith("program.")))
			{
			System.out.println("I like java.");
			}else{
			System.out.println("I hate java.");
			}
		String s4=s.concat(s3)	;
		System.out.println(s4);

		int index=s.indexOf('a');
		System.out.println("First a is available in : "+index);

		int index1=s.indexOf('a',(index+1));
		System.out.println("Second a is available in : "+index1)			;

		int index2=s.indexOf('R');
		System.out.println("If R is not available : "+index2);

		int index3=s.lastIndexOf('a');
		System.out.println("Last a is available in : "+index3);

		String sub=s.substring(s.indexOf('j'),s.length());
		System.out.println(sub)		;

		}
	}

		
			
		
		
