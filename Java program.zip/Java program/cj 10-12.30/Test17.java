public class Test17
	{
	public static void main(String args[])
		{
		System.out.println(19 & 33);//1
		System.out.println(233 | 205);//237
		System.out.println(79 ^ 119);//56
		}
	}
