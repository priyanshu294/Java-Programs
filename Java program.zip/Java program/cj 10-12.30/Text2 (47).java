public class Text2
	{
	public static void main(String args[])
		{
		int a=5;
		a=a++;
		System.out.println(a);
		int b=a++;
		System.out.println(a+"\t"+b);
		a=++a;
		System.out.println(a);
		b=++a;
		System.out.println(a+"\t"+b);
		}
	}
