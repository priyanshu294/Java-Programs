class X
	{
	public String getMessage(String s)
		{
		System.out.println("I am in base class.");
		return s;
		}
	}
class Y extends X
	{
	public String getMessage(String msg)
		{
		System.out.println("I am in sub class.");
		return msg;
		}
	}
public class Test1
	{
	public static void main(String args[])
		{
		X ab=new Y();
		System.out.println("Message is : "+ab.getMessage("I Like Java Technocrat."));
		}
	}

	
