import java.lang.reflect.*;
public class Test
	{
	public static void main(String args[])
		{
		try{
		Class c=Class.forName("Demo");
		Demo dd=(Demo)c.newInstance();
		Method mm=c.getDeclaredMethod("getData",null);
		mm.setAccessible(true);
		mm.invoke(dd,null);
		}catch(Exception ee)
			{
			ee.printStackTrace();
			}
		}
	}
