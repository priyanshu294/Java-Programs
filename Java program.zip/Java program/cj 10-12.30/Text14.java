public class Text14
	{
	public static void main(String args[])
		{
		short s1=10;
		short s2=20;
		s1*=s2;
		System.out.println(s1);
		}
	}
