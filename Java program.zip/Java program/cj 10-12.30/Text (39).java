class A
	{
	int i;
	}
class B extends A
	{
	int j;
	}
public class Text
	{
	public static void main(String args[])	
		{
		B bb=new B();
		bb.i++;
		bb.j++;
		System.out.println(bb.i+"\t"+bb.j);
	A aa=bb;//auto conversion of Object reference
		aa.i++;
		//aa.j++;
		System.out.println(aa.i);
	B ab=(B)aa;//type casting of Object reference
		ab.i++;
		ab.j++;
		System.out.println(ab.i+"\t"+ab.j);
		}
	}

			
