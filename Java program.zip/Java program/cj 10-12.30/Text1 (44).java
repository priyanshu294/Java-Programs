public class Text1
	{
	public static void main(String args[])
		{
		System.out.println("I am in main method.");
		try{
		Class.forName("p1.X");//X.class
		System.out.println("Class is explicitly loaded by ClassLoader.");
		}catch(ClassNotFoundException ce)
			{
			System.out.println("I am unable to load class file.");
			}
		System.out.println("I am quit from main.");
		}
	}
