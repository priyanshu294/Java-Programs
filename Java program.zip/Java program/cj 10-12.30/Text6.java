public class Text6
	{
	void call(String s)
		{
		System.out.println("String class.");
		}
	void call(Integer obj)
		{
		System.out.println("Integer class.");
		}
	public static void main(String args[])
		{
		Text6 tt=new Text6();
		tt.call(null);
		}
	}
