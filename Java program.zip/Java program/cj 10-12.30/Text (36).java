public class Text
	{
	public static void main(String args[])
		{
		try{
		Class cc=Class.forName("Demo");
		Demo dd=(Demo)cc.newInstance();
		System.out.println(dd.getName()+"\t"+dd.getRoll());
		dd.setName("Java Technocrat.");
		dd.setRoll(1);
		System.out.println("Name is : "+dd.getName()+"\tRoll number is : "+dd.getRoll());
		}catch(ClassNotFoundException ce)
			{
			System.out.println("Class Not Found.");
			}
		catch(Exception ee)
			{
			}
		}
	}
