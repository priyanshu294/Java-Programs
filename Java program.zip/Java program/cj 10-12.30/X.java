package p1;
public class X
	{
	static{
	System.out.println("I am in the class Block of X class.")	;
	}
	}
	