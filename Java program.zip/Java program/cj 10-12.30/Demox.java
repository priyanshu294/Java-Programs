public class Demox
	{
	public static void m1(int...a)
		{
		System.out.println("I am in m1");
		}
	public static void main(String args[])
		{
		m1(12,33,45);
		m1(12,44);
		m1(33);
		m1();
		}
	}