class A
	{
	int i;
	}
class B extends A
	{
	int j;
	public static A getObject1()
		{
		B bb=new B();
		bb.i++;
		bb.j++;
		return bb;
		}
	public static A getObject2()
		{
		A aa=new A();
		return aa;
		}
	}
public class Test
	{
	public static void main(String args[])
		{
		if(B.getObject1() instanceof B)
			{
			B b1=(B)B.getObject1();
			System.out.println(b1.i+"\t"+b1.j);
			}else{
			System.out.println("Unable to call the method.");
			}
		if(B.getObject2() instanceof B)	
			{
			B b2=(B)B.getObject2();
			System.out.println(b2.i);
			}else{
			System.out.println("Unable to call the method.");
			}
		}
	}

	