import java.lang.reflect.*;
public class Test1
	{
	public static void main(String args[])
		{
		try{
		Class c=Class.forName("Demo1");
		Demo1 dd=(Demo1)c.newInstance();
		Method mm=c.getDeclaredMethod("cube",new Class[]{int.class});
		mm.setAccessible(true);
		mm.invoke(dd,5);
		}catch(Exception ee)
			{
			ee.printStackTrace();
			}
		}
	}
