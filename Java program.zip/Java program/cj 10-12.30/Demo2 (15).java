enum Abc
	{
	java,python,android,c,cpp;
	}
public class Demo2
	{
	public static void main(String args[])
		{
		Abc x[]=Abc.values();
		for(Abc y : x)
			{
System.out.println(y+" Ordinal is "+y.ordinal());
			}
		}
	}