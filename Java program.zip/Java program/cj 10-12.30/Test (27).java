class X
	{
	public void add(double a,double b)
		{
		System.out.println("Sum is : "+(a+b));
		}
	}
class Y extends X
	{
	public void add(int a,int b)
		{
		System.out.println("Addition is : "+(a+b));
		}
	}
public class Test
	{
	public static void main(String args[])
		{
		X ab=new Y();
		ab.add(10,20);
		}
	}
