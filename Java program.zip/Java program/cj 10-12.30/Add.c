#include<stdio.h>
#include"jni.h"
#include"Add.h"
void call(int *a,int *b)	
	{
	(*a)++;
	(*b)++;
	printf("After call the function value is : %d %d\n",*a,*b)	;
	}
JNIEXPORT jint JNICALL Java_Add_add(JNIEnv *a,jclass c,jint num1,jint num2)
	{
	printf("Before call the function value is : %d %d \n",num1,num2);
	call(&num1,&num2);
	return (num1+num2);
	}