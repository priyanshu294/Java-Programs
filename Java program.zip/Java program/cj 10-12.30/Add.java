import java.util.Scanner;
public class Add
	{
	public static native int add(int a,int b);
	public static void main(String args[])
		{
		Scanner ss=new Scanner(System.in);
		System.out.println("Enter first number.");
		int num1=ss.nextInt();
		System.out.println("Enter second number.");
		int num2=ss.nextInt();
		int sum=add(num1,num2);
		System.out.println("Sum is : "+sum);
		}
	static{
	System.loadLibrary("Add")	;//Add.lib
	}
	}
