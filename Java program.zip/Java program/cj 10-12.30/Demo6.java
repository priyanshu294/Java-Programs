interface A
	{
	void call();
	}
interface B extends A
	{
	void calls();
	}
public class Demo6 implements B
	{
	@Override
	public void call()
		{
		System.out.println("I am the method of Base Interface");
		}
	@Override
	public void calls()
		{
System.out.println("I am the method of Child Interface");
		}
	public static void main(String args[])
		{
		A ab=new Demo6();
		ab.call();
		((B)ab).calls();
		}
	}