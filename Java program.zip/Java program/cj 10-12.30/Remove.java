import java.util.*;

public class Remove
	{
	public static void main(String args[])
		{
		Scanner ss=new Scanner(System.in);
		System.out.println("ENter the size");
		int size=ss.nextInt();
		int arr[]=new int[size];
	System.out.println("ENter "+size+" Numbers");
		for(int i=0;i<size;i++)
			{
			arr[i]=ss.nextInt();
			}
		int x=0;
		int temp[]=new int[size];
		
		for(int i=0;i<size-1;i++)
			{
			if(arr[i]!=arr[i+1])
				{
				temp[x++]=arr[i];
				}		
			}
		temp[x++]=arr[size-1];
		
		for(int i=0;i<x;i++)
			{
			arr[i]=temp[i];
			}
		for(int a : arr)
			{
			System.out.print(a+" ");
			}
		}
	}
					
				
	
		
		
		