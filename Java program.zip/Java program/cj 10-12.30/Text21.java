public class Text21
	{
	public static void main(String args[])
		{
		int i=65;
		switch(i)
			{
			case 65:
			System.out.println("A");
			break;

			case 'A':
			System.out.println("B");
			break;

			default:
			System.out.println("C");
			break;
			}
		}
	}

	