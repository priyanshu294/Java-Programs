public class Demo4
	{
	String name;
	public void setName(String name)
		{
		this.name=name;
		}
	public String getName()		
		{
		return name;
		}
	public static void main(String args[])
		{
		Demo4 dd=new Demo4();
		dd.setName("Java Technocrat.");
		System.out.println("Name is : "+dd.getName());
		}
	}

	
		
