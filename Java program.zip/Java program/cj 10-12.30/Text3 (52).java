public class Text3
	{
	int roll;
	String name;
	Text3()
		{
		System.out.println("Object is constructed.");
		}
	Text3(int roll)
		{
		
		this.roll=roll;
		this();	
		}
	Text3(String name)
		{
		this(12);
		this.name=name;
		}
	public static void main(String args[])	
		{
		Text3 tt=new Text3("Java Technocrat");
		System.out.println("Name is : "+tt.name+"\tRoll number is : "+tt.roll);
		}
	}


	