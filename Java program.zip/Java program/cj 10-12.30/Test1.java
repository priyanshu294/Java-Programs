package c2;


public class Test1
	{
	public int roll;
	public void setRoll(int roll)
		{
		this.roll=roll;
		}
	public int getRoll()
		{
		return roll;
		}
	}