public class Text
	{
	public Text()
		{
		System.out.println("Java Object is Constructed.");
		}
	public native void call();
	public static void main(String args[])
		{
		Text tt=new Text();
		tt.call();
		}
	static{
	System.loadLibrary("Text");//Text.lib
	}
	}

