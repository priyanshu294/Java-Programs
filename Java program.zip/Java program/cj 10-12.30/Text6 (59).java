public class Text6
	{
	public static void main(String args[])
		{
		System.out.println(~23);//-24
		System.out.println(~(-34));//33
		}
	}
