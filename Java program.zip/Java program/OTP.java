public class OTP
	{
	public static void main(String args[])
	{
	
	for(int i=1;i<=10;i++)
		{
int a=((int)(Math.random()*100000));
if(a>999 && a<10000)
	System.out.println(a*10);
else if(a>99 && a<1000)
	System.out.println(a*100);
else
	System.out.println(a);
		}
	}
	}