import java.applet.*;

public class ViewPanel extends Applet
	{
	PanelDemo pd;
	public void init()
		{
		pd=new PanelDemo();
		add(pd);
		}
	}
/*
<applet code="ViewPanel" width="400" height="400">
</applet>
*/
	