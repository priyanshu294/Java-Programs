import java.awt.*;
import java.applet.*;

public class Demo2 extends Applet
	{
	Panel p1,p2,p3;	
	TextField tf;
	Button b;
	Label l;
	Font f;
	
	public void init()
		{
		p1=new Panel();
		p2=new Panel();
		p3=new Panel();
		setLayout(new GridLayout(3,1));
		setVisible(true);
		
		
		tf=new TextField(20);
		f=new Font("Arial",Font.BOLD,25);
		b=new Button("Login");
		l=new Label("Enter Name");
		tf.setFont(f);
		b.setFont(f);
		l.setFont(f);
		p1.add(l);
		p2.add(tf);
		p3.add(b);
		add(p1);
		add(p2);
		add(p3);
		}
	}
/*
<applet code="Demo2" width="400" height="400"></applet>
*/