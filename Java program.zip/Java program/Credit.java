package asset;
import java.util.Scanner;
public class Credit
{
public int credit;
public int showcredit()
{
Scanner ss=new Scanner(System.in);
System.out.println("Enter how much you want to withdraw from Account");
credit=ss.nextInt();
return 0;
}
}