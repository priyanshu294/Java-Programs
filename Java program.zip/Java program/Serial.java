import java.io.*;
class Emp implements Serializable
	{
	int id;
	String name;
	transient double sal;
	void setData(int id,String name,double sal)
		{
		this.id=id;
		this.name=name;
		this.sal=sal;
		}
	}
public class Serial
	{
	public static void main(String args[])
		{
		try{
		FileOutputStream fos=new FileOutputStream("ee.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		Emp ee= new Emp();
		ee.setData(101,"Sagar",23000.99);
		oos.writeObject(ee);
		oos.close();
		fos.close();
		System.out.println("Object is Serialized.");
		}catch(Exception ee)
			{
			}
		}
	}