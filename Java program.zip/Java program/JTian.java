import java.sql.*;

public class Demo
	{
	public static void main(String args[])
		{
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","manager");
		
		Statement st=cn.createStatement();
		
	int i=st.executeUpdate("create table stud(name varchar2(20),password varchar2(20))");
		
	if(i>=0)
		{
		System.out.println("Table is Successfully Created");
		}else{
		System.out.println("Unable to create the table");
		}
	}catch(Exception ee)
		{
		ee.printStackTrace();
		}
	}
}		 