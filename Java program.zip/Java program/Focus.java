import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class Focus extends Applet implements FocusListener
	{
	TextField tf1,tf2;
	Font f;
	String msg;
	public void init()
		{
		tf1=new TextField(15);
		tf2=new TextField(15);
		f=new Font("Arial",Font.BOLD,23);
		tf1.setFont(f);
		tf2.setFont(f);
		tf1.addFocusListener(this);
		tf2.addFocusListener(this);
		add(tf1);
		add(tf2);
		}
	@Override
	public void focusGained(FocusEvent fe)
		{}
	
	@Override
	public void focusLost(FocusEvent fe)
		{
		repaint();
		}
	@Override
	public void paint(Graphics g)
		{
	g.setFont(new Font("Arial",Font.BOLD,20));
	String s1=tf1.getText();
	
	if(s1.equals(""))
		{
		msg="Please fill the Textfield1";
		g.drawString(msg,5,200);
		}else{
	g.drawString(s1,5,200);
		}
		}
	}
/*
<applet code="Focus" width="100" height="500"></applet>
*/
		
		
		
		
		
		
		

