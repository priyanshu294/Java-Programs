public class Demo5
	{
	public static void main(String args[])
	{
	double a=44.5;
	double b=99.2;
	
	System.out.println(Math.sin(b));
	System.out.println(Math.cos(b));
	System.out.println(Math.tan(b));
	System.out.println(Math.sinh(b));
	System.out.println(Math.cosh(b));
	System.out.println(Math.tanh(b));
	
System.out.println(Math.abs(-12.98));
System.out.println(Math.abs(-11));
System.out.println(Math.abs(99));

System.out.println(Math.min(a,b));
System.out.println(Math.max(a,b));
System.out.println(Math.ceil(b));//100.0
System.out.println(Math.floor(a));//44.0
System.out.println(Math.round(a));//45

System.out.println(Math.sqrt(16));//4.0
System.out.println(Math.cbrt(27));//3.0
System.out.println(Math.pow(4,3));//64.0
System.out.println(Math.log(10));//1.0
System.out.println(Math.random());//

		}
	}











	
	
	
	
	
	