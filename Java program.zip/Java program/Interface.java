interface Animal
{
public void eat(); //declare a method
void sleep();
}
class Lion implements Animal
{
@Override
public void eat() // define a method
{
System.out.println("I eat Meat");
}
@Override
public void sleep() // define a method
{
System.out.println("I sleep the cave");
}
}
class Rabbit implements Animal
{
@Override
public void sleep() // define a method
{
System.out.println("I sleep in busses");
}
@Override
public void eat() // define a method
{
System.out.println("I eat carrot");
}
}
class Zoo
{
public static void sendAnimal(Animal aa)
{
aa.eat();
aa.sleep();
}
}
public class Interface
{
public static void main(String args[])
{
Lion ll=new Lion();
Rabbit rr=new Rabbit();
	Zoo.sendAnimal(ll);
	Zoo.sendAnimal(rr);
}
}