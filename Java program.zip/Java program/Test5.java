public class Test5
	{
	public static void main(String args[])
	{
	int i=10,j=20;
	if((i++>10)&&(++j>20))
		{
		i++;
		j++;
		}else{
		i--;
		j--;
		}
	System.out.println(i+"\t"+j)	;
	int x=10,y=20;
	if((x++>10)&(++y>20))
		{
		x++;
		y++;
		}else{
		x--;
		y--;
		}
	System.out.println(x+"\t"+y);
	}
	}
	
		