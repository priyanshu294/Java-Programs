public class Demo2
	{
	private static String name;
	public static class Xyz
		{
	public static String getName()
			{
			return name;
			}
	public void setName(String n)
			{
			name=n;
			}
		}
public static void main(String args[])	
		{
		Xyz ii=new Xyz();
		ii.setName("Raaj");
System.out.println(Xyz.getName());
		}
	}