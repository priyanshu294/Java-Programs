import java.io.*;
public class Shutdown
{
public static void main(String arg[]) throws IOException
{
Runtime rt = Runtime.getRuntime();
Process proc = rt.exec("shutdown -s");
System.exit(0);
}
}