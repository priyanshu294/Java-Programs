import java.awt.*;
import java.applet.*;

public class Face extends Applet
	{
	public void init()
		{
		setBackground(Color.black);
		}
	public void paint(Graphics g)
		{
		g.setColor(Color.yellow);
		g.fillOval(20,20,200,200);
		g.setColor(Color.black);
		g.fillOval(60,60,30,30);
		g.fillOval(140,60,30,30);
		g.drawLine(115,70,115,130);
		g.drawLine(115,130,90,110);
		g.drawArc(70,110,100,70,0,-180);
		}
	}
/*
<applet code="Face" width="400" height="400">
</applet>
*/ 