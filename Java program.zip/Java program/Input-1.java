import java.io.*;
public class Input
	{
	public static void main(String args[])
		{
		try{
		InputStreamReader is=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(is);
		System.out.println("Enter a line.");
		String data=br.readLine();
		System.out.println("Data is : "+data);
		}catch(IOException ie)
			{
			}
		}
	}
