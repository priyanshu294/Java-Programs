import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class Text extends Applet implements TextListener
	{
	TextField tf;
	Font f;
	String txt;
	public void init()
		{
		tf=new TextField(20);
		f=new Font("Arial",Font.BOLD,23);
		tf.setFont(f);
		tf.addTextListener(this);
		add(tf);
		}
	@Override
	public void textValueChanged(TextEvent te)
		{
		repaint();
		}
	@Override
	public void paint(Graphics g)
		{
		g.setColor(Color.red);
		g.setFont(new Font("Verdana",Font.BOLD+Font.ITALIC,30));
		txt=tf.getText();
		g.drawString(txt,40,100);
		}
	}
/*
<applet code="Text" width="500" height="500"></applet>
*/
		
