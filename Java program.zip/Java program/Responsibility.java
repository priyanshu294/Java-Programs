package liable;
import java.util.Scanner;
public class Responsibility
{
public static long accountno;
public static String name;
public void input()
{
 System.out.println("person who enter the below requirement is responsible for the balance variation in the account");
Scanner ss=new Scanner(System.in);
System.out.println("Enter your name and Account number");
name=ss.nextLine();
accountno=ss.nextInt();
}
public void show()
{
System.out.println("WELCOME "+name+"Your account number is "+accountno);
}
}