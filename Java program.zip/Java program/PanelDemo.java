import java.awt.*;

public class PanelDemo extends Panel
	{
	Button b1;
	TextField tf;
	Label l;
	Font f;
	
	public PanelDemo()
		{
		b1=new Button("Submit");
		l=new Label("Enter Your Password");
		tf=new TextField(12);
		f=new Font("Arial",Font.BOLD,26);
		b1.setFont(f);
		l.setFont(f);
		tf.setFont(f);
			
		tf.setEchoChar('*');
		
		add(l);
		add(tf);
		add(b1);
		}
	public static void main(String args[])
		{
		PanelDemo pd=new PanelDemo();
		}
	}
			
	