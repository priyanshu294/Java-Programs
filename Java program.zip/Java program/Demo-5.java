import java.applet.*;
import java.awt.*;

public class Demo extends Applet
	{
	public void init()
		{
		setBackground(Color.cyan);
		}
	public void paint(Graphics g)
		{
		g.setColor(Color.red);
		g.fillOval(100,50,100,100);
		g.setColor(Color.green);
		g.fillRect(20,100,200,100);
		g.setColor(Color.black);
	Font f=new Font("Algerian",Font.BOLD,30);
		g.setFont(f);	
		g.drawString("Hello JTian",30,300);
		}
	}
/*
<applet code="Demo" width="400" height="400">
</applet>
*/
		