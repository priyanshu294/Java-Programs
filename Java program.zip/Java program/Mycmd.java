import java.io.*; 

    public class Mycmd 
    { 
        public static void main(String args[]) 
        { 
            try 
            { 
                Process p=Runtime.getRuntime().exec("cmd /c start echo Welcome to my cmd  :) Sanjan Patel.....  "); 
                p.waitFor(); 
                BufferedReader br=new BufferedReader (new InputStreamReader( p.getInputStream()) ) ; 

                String line=br.readLine(); 

                while(line!=null) 
                { 
                    System.out.println(line); 
                    line=br.readLine(); 
                } 

            }
            catch(IOException e1) {} 
            catch(InterruptedException e2) {} 

            System.out.println("Done"); 
        } 
    }