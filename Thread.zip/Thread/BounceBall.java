import java.awt.*;
import java.applet.Applet;
public class BounceBall extends Applet implements
Runnable
	{
	int y1,g1,b,c=1;
	int x=0;
	int y=250;
	Thread t;
	public void init()
		{
		setBackground(Color.cyan);
		}
	public void start()
		{
		t=new Thread(this);
		t.start();
		}
	public void stop()
		{
		t.stop();
		t=null;
		}
	public void paint(Graphics g)
		{
		g.setColor(Color.red);
		g.fillOval(x,y,50,50);
		}
	public void run()
		{
		while(true)
			{
			for(x=0;x<=500;x++)
				{
				if(x<=250)
					y+=1;
				if(x>=250)
					y-=1;
				repaint();
				try{
				Thread.sleep(200);	
			   	}catch(InterruptedException ee)
					{
					}
				}
			x=500;
			y=250;
			for(x=500;x>=0;x--)
				{
				if(x>=250)
					y-=1;
				if(x<=250)
					y+=1;
				repaint();
				try{
				Thread.sleep(200);
				}catch(InterruptedException ee)
					{
					}
				}
			}

		}
	}
/*<applet code="BounceBall" width=550 height=550></applet>*/
