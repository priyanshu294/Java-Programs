import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*<applet code="BallRunning.class" width=400 height=400>
</applet>*/
public class BallRunning extends Applet implements Runnable,ActionListener
        {
        Thread t=null;
        int i,j;
        boolean stopFlag;
        Button b1,b2,b3,b4;
        public void init()
                {
                b1=new Button("START");
                b2=new Button("RESUME");
                b3=new Button("SUSPEND");
                b4=new Button("STOP");
                setBackground(Color.orange);
                add(b1);
                add(b2);
                add(b3);
                add(b4);
                b1.addActionListener(this);
                b2.addActionListener(this);
                b3.addActionListener(this);
                b4.addActionListener(this);
        }
        public void actionPerformed(ActionEvent ae)
        {
                Object o=ae.getSource();
                if(o==b1)
                        {
                        if(t==null)
                                {
                                t=new Thread(this);
                                stopFlag=false;
                                t.start();
                                }
                        }
                if(o==b2)
                        
                        t.resume();
                        
                if(o==b3)
                        
                        t.suspend();
                        
                if(o==b4)
                        {
                        if(t!=null)
                                {
                                stopFlag=true;
                                t=null;
                                                  
                                t.stop();
                                }
                         }
          }
        public void run()
        {

                for(i=0,j=400; ;i++,j--)
                {
                        try{
                                repaint();
                                Thread.sleep(70);
                                if(stopFlag)
                                break;
                           }
                        catch(InterruptedException e){}
                }      
        }
        public void paint(Graphics g)
        {
                g.setColor(Color.blue);
                g.fillOval(i+85,i+45,80,80);
                g.setColor(Color.red);
                g.fillOval(j-15,j-45,80,80);
        }                            
}

        
                

        

