public class Text extends Thread
	{
	String name;
	Demo dd;
	Text(Demo dd,String name)
		{
		super(name);
		this.dd=dd;
		start();
		}
	public static void main(String args[])
		{
		Demo dd=new Demo();
		Text t1=new Text(dd,"First");
		Text t2=new Text(dd,"Second");
		Text t3=new Text(dd,"Third");
		}
	@Override
	public void run()
		{
		synchronized(dd){
		dd.display(Thread.currentThread().getName());
		}
		}
	}

		
	