import java.awt.*;
import java.awt.event.*;
import java.applet.*;
public class CircleGrowing extends Applet implements ActionListener,Runnable
{
   Button b1,b2,b3,b4;
   Thread t;
   Label l1,l2,l3;
   int speed,md,Md;
   public static int i=1;
   TextField tf1,tf2,tf3;
   public void init()
   {

       setBackground(Color.green);

       b1=new Button("START");
       b2=new Button("SUSPEND");
       b3=new Button("RESUME");
       b4=new Button("STOP");

       l1=new Label("speed of motion");
       l2=new Label("maximum diameter");
       l3=new Label("minimum diameter");

       tf1=new TextField(5);
       tf2=new TextField(5);
       tf3=new TextField(5);

       b1.addActionListener(this);
       b2.addActionListener(this);
       b3.addActionListener(this);
       b4.addActionListener(this);

       add(l1);
       add(tf1);
       add(l2);
       add(tf2);
       add(l3);
       add(tf3);
       add(b1);
       add(b2);
       add(b3);
       add(b4);

   }
   public void actionPerformed(ActionEvent ae)
   {
      Object o=ae.getSource();
      if((o==b1)&&(t==null))
      {
            t=new Thread(this);
            t.start();
      }
      else if((o==b2)&&(t!=null))
      {
      t.suspend();
      }
      else if((o==b3)&&(t!=null))
      {
      t.resume();
      }
      else{
      if(t!=null)
      {
         t.stop();
         t=null;
       }
       }
   }

   public void run()
   {
      speed=Integer.parseInt(tf1.getText());
     Md=Integer.parseInt(tf2.getText());
     md=Integer.parseInt(tf3.getText());

   
       while(i<=Md)
       {
           try{
           
           repaint();
           Thread.sleep(speed);
           if(i==Md)
           {
            while(i>=md)
            {
               repaint();
               Thread.sleep(speed);
               if(i==md)
                   break;
               i--;
           }
           }
           i++;
                    
       }

           catch(Exception e)
           {
           }
           
       }
   }
   public void paint(Graphics g)
   {
      
        g.setColor(new Color(((int)(Math.random()*1000))%254,((int)(Math.random()*1000))%254,((int)(Math.random()*1000))%254));
        g.fillOval(20,30,i,i);
   }
   }
/*<applet code="CircleGrowing" width=800 height=800>
</applet>*/

