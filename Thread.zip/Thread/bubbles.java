import java.awt.*;
import java.awt.event.*;
import java.applet.*;
public class bubbles extends Applet implements ActionListener,Runnable
{
int d=100;
Thread t,t1;
Button b1,b2,b3,b4;
int i,m,j;
TextField tf2,tf1;
Label l1,l2;
	public void init()
      {
	l1=new Label("Enter Speed in ms");
	tf1=new TextField(5);
	b1=new Button("start");
	b2=new Button("stop");
	b3=new Button("pause");
	b4=new Button("Resume");
	b1.addActionListener(this);
	b2.addActionListener(this);
	b3.addActionListener(this);
	b4.addActionListener(this);
	add(l1);
	add(tf1);
	add(b1);
	add(b2);
	add(b3);
	add(b4);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if((ae.getSource()==b1)&&(t==null))
		{
		t=new Thread(this);
		//t1=new Thread();
		t.start();
		//t1.start();
		}
		else if((ae.getSource()==b2)&&(t!=null))
		{
		t.stop();
		t=null;
		//t1.stop();
		//t1=null;
		}
		else if((ae.getSource()==b3)&&(t!=null))
		{
		t.suspend();
		//t1.suspend();

		}
		else if((ae.getSource()==b4)&&(t!=null))
		{
		t.resume();
		//t1.resume();
		}
	}
	public void run()
	{
	m=((int)(Math.random()*1000))%700;
	for(j=500;;j--)
	{
	if(j<-100){m=((int)(Math.random()*1000))%700;
	j=500;}
	repaint();
	try{Thread.sleep(Integer.parseInt(tf1.getText()));}
	catch(Exception e){}
	}
	}
	public void paint(Graphics g)
	{	
		
		for(int k=0,i=d;i>0;i--,k++)
		{
		g.setColor(new Color(150+k,250,40+k));
		g.drawOval((m+300)%700+k/2,k/2+j,i,i);
		}
		for(int k=0,i=d;i>0;i--,k++)
		{
		g.setColor(new Color(150+k,254,150+k));
		g.drawOval(k/2+(m%700),k/2+j,i,i);
		}
		for(int k=0,i=d;i>0;i--,k++)
		{
		g.setColor(new Color(150+k,254,254));
		g.drawOval(k/2+(m+500)%700,k/2+j,i,i);
		}


	}
}
/*<applet code="bubbles" width=500 height=500>
</applet>*/