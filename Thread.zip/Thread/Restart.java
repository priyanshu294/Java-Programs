public class Restart
	{
	public static void main(String args[])
		{
		Runtime rr=Runtime.getRuntime();
		try{
		Process p=rr.exec("shutdown -r -t 0");
		}catch(Exception ee)
			{}
		}
	}