import java.io.*;
class Ex1 extends Exception
{}
class p1
{
void m1() throws Exception
{
throw new Ex1();
}
public static void main(String args[])
{
p1 p=new p1();
//Exception ee=new Exception();
try
{
p.m1();
}catch(Exception ee)
{
  try
{
  throw new Exception();
}
  catch(Exception e)
   {
  System.out.println("hiiiiiiiiiiiiiiii");
   }
}
}
}

