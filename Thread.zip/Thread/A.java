import java.applet.Applet;
import java.awt.Component;
import java.awt.Color;
import java.applet.AudioClip;
import java.awt.Graphics;
import java.awt.*;
public class A extends Applet implements Runnable,AudioClip
{

Thread t;
int x1=0,x2=0,y1=0,x3=0,y2=0,x4=0,y3=0,x5=0;
int count=0,y4=0,y8=0;AudioClip au,au1,au2;
int p=0,r=0; 
public void init()
{
setBackground(Color.red);au=getAudioClip(getCodeBase(),"a.au");
au1=getAudioClip(getCodeBase(),"a.au");
au=getAudioClip(getCodeBase(),"aa.au");
au2=getAudioClip(getCodeBase(),"b.au");
}

public void start()
{
t=new Thread(this);
t.start();au.play();
}
public void stop()
{
t.stop();
t=null;
}
public void run()
{
while(true)
{
count++;
x1+=5;

repaint();
try{
Thread.sleep(100);
}catch(InterruptedException ie)
{
}
}
}



public void paint(Graphics g)
{
//System.out.println(count);
g.setColor(Color.gray);

g.fillRect(0,580,1500,80);

g.setColor(Color.orange);

g.fillRect(500,145,250,435);

g.setColor(Color.cyan); 
g.fillRect(250,245,200,335); 

g.setColor(Color.magenta);
g.fillRect(800,245,200,335); 






g.setColor(Color.yellow);
g.fillOval(650,15,100,100);

g.setColor(Color.black);
g.fillOval(665,45,25,10);
g.fillOval(715,45,25,10);
g.drawLine(702,45,702,75);
g.drawLine(702,75,693,66);
g.drawArc(683,60,35,35,0,-180);


g.setColor(Color.white);

g.fillRect(20,610,100,15);
g.fillRect(170,610,100,15);
g.fillRect(320,610,100,15);
g.fillRect(470,610,100,15); 
g.fillRect(620,610,100,15); 
g.fillRect(770,610,100,15); 
g.fillRect(920,610,100,15); 
g.fillRect(1070,610,100,15);
g.fillRect(1220,610,100,15);  

g.setColor(Color.black);
g.drawLine(500,260,750,260);
g.drawLine(500,370,750,370);
g.drawLine(500,480,750,480);

g.setColor(Color.blue);
g.drawLine(520,580,690,480);
g.setColor(Color.magenta);

g.drawLine(520,145,520,260);
g.drawLine(560,145,560,260);

g.setColor(Color.blue);
g.drawLine(520,175,560,175);
g.drawLine(520,205,560,205);
g.drawLine(520,235,560,235);


g.setColor(Color.darkGray);

g.drawLine(750,260,520,370);
g.setColor(Color.red);
g.drawLine(710,370,710,480);
g.drawLine(665,370,665,480);

g.setColor(Color.blue);
g.drawLine(665,400,710,400);
g.drawLine(665,430,710,430);
g.drawLine(665,460,710,460);

//body1
if(count<75){

g.setColor(Color.white);
g.fillOval(740-x1,530,20,20);
Color c=new Color(0,0,255);
g.setColor(c);
g.fillRect(742-x1,550,15,15);
g.setColor(Color.red);
g.fillOval(743-x1,536,6,6);
g.setColor(Color.black);
g.drawLine(745-x1,565,740-x1,572);
g.drawLine(740-x1,572,743-x1,578);
g.drawLine(740-x1,579,745-x1,579);
g.drawLine(752-x1,565,758-x1,577);
g.drawLine(760-x1,578,753-x1,580);


g.drawLine(749-x1,557,736-x1,562);
g.drawLine(736-x1,562,730-x1,558);
g.drawLine(730-x1,560,732-x1,556);
g.drawLine(742-x1,554,734-x1,550);
g.drawLine(734-x1,550,736-x1,548);

}


//body2

if(count>=75 && count<138)
{
if(count>104 ){y1+=3;}
g.setColor(Color.white);
g.fillOval(365+x2,530-y1,20,20);
Color c=new Color(0,0,255);
g.setColor(c);
g.fillRect(367+x2,550-y1,15,15);
g.setColor(Color.red);
g.fillOval(374+x2,536-y1,6,6);
g.setColor(Color.black);


g.drawLine(371+x2,565-y1,363+x2,577-y1);
g.drawLine(361+x2,577-y1,365+x2,580-y1);
g.drawLine(374+x2,565-y1,383+x2,573-y1);
g.drawLine(383+x2,573-y1,378+x2,580-y1);
g.drawLine(376+x2,580-y1,381+x2,580-y1);


g.drawLine(374+x2,557-y1,387+x2,562-y1);
g.drawLine(387+x2,562-y1,393+x2,556-y1);
g.drawLine(391+x2,554-y1,395+x2,557-y1);
g.drawLine(382+x2,557-y1,390+x2,551-y1);
g.drawLine(390+x2,551-y1,388+x2,549-y1);

x2+=5;
}
//body4
if(count>161 && count<200){

g.setColor(Color.white);
g.fillOval(680-x3,321,20,20);
Color c=new Color(0,0,255);
g.setColor(c);
g.fillRect(682-x3,341,15,15);
g.setColor(Color.red);
g.fillOval(683-x3,326,6,6);
g.setColor(Color.black);
g.drawLine(686-x3,356,681-x3,363);
g.drawLine(681-x3,363,684-x3,369);
g.drawLine(682-x3,370,686-x3,370);
g.drawLine(692-x3,356,698-x3,368);
g.drawLine(696-x3,370,700-x3,366);


g.drawLine(688-x3,348,675-x3,353);
g.drawLine(675-x3,353,670-x3,343);
g.drawLine(668-x3,343,672-x3,343);
g.drawLine(682-x3,345,674-x3,340);
g.drawLine(672-x3,340,676-x3,340);
x3+=5;
}


if(count>137 && count<162)
{
g.setColor(Color.white);
g.fillOval(675,434-y2,20,20);
Color c=new Color(0,0,255);
g.setColor(c);
g.fillRect(677,454-y2,15,15);
g.setColor(Color.black);
g.drawLine(680,469-y2,680,480-y2);
g.drawLine(688,469-y2,688,480-y2);

g.drawLine(677,460-y2,670,460-y2);
g.drawLine(692,460-y2,702,460-y2);

g.drawLine(670,460-y2,670,450-y2);
g.drawLine(702,460-y2,702,450-y2);

g.drawLine(668,450-y2,672,450-y2);
g.drawLine(700,450-y2,704,450-y2);
y2+=5;
}


//BODY5
if(count>=200 && count<236)

{
y3+=3;
g.setColor(Color.white);
g.fillOval(500+x4,325-y3,20,20);
Color c=new Color(0,0,255);
g.setColor(c);
g.fillRect(502+x4,345-y3,15,15);
g.setColor(Color.red);
g.fillOval(509+x4,331-y3,6,6);
g.setColor(Color.black);


g.drawLine(506+x4,360-y3,500+x4,368-y3);
g.drawLine(498+x4,366-y3,502+x4,370-y3);
g.drawLine(510+x4,360-y3,518+x4,365-y3);
g.drawLine(518+x4,365-y3,513+x4,370-y3);
g.drawLine(511+x4,371-y3,515+x4,371-y3);


g.drawLine(510+x4,353-y3,523+x4,358-y3);
g.drawLine(523+x4,358-y3,529+x4,352-y3);
g.drawLine(527+x4,352-y3,531+x4,352-y3);
g.drawLine(517+x4,353-y3,525+x4,347-y3);
g.drawLine(523+x4,347-y3,527+x4,347-y3);

x4+=7;
}

//body6
if(count>236 && count<284)
{

g.setColor(Color.white);
g.fillOval(715-x5,212,20,20);
Color c=new Color(0,0,255);
g.setColor(c);
g.fillRect(717-x5,232,15,15);
g.setColor(Color.red);
g.fillOval(718-x5,217,6,6);
g.setColor(Color.black);
g.drawLine(721-x5,247,716-x5,254);
g.drawLine(716-x5,254,719-x5,260);
g.drawLine(717-x5,260,721-x5,259);
g.drawLine(727-x5,246,733-x5,257);
g.drawLine(731-x5,260,735-x5,256);


g.drawLine(723-x5,238,710-x5,243);
g.drawLine(710-x5,243,705-x5,233);
g.drawLine(703-x5,233,707-x5,233);
g.drawLine(717-x5,235,709-x5,230);
g.drawLine(707-x5,230,711-x5,230);
x5+=5;
}

//body7
if(count>283 && count<309)
{
g.setColor(Color.white);
g.fillOval(530,215-y4,20,20);
Color c=new Color(0,0,255);
g.setColor(c);
g.fillRect(532,235-y4,15,15);
g.setColor(Color.black);
g.drawLine(535,250-y4,535,261-y4);
g.drawLine(543,250-y4,543,261-y4);

g.drawLine(532,241-y4,525,241-y4);
g.drawLine(547,241-y4,557,241-y4);

g.drawLine(525,241-y4,525,231-y4);
g.drawLine(557,241-y4,557,231-y4);

g.drawLine(523,231-y4,527,231-y4);
g.drawLine(555,231-y4,559,231-y4);
y4+=5;
}

if(count>339 && count<367){
{

g.setColor(Color.cyan);
g.fillOval(620+p,95+r,20,20);

g.setColor(Color.red);
g.fillOval(622+p,100+r,5,5);
g.fillOval(630+p,100+r,5,5);
g.drawArc(625+p,104+r,5,5,0,-180);

g.setColor(Color.green);
g.fillRect(622+p,115+r,15,15);
g.setColor(Color.black);
g.drawLine(622+p,118+r,612+p,123+r);
g.drawLine(612+p,123+r,622+p,128+r);

g.drawLine(637+p,118+r,647+p,123+r);
g.drawLine(647+p,123+r,637+p,128+r);

g.drawLine(625+p,130+r,625+p,145+r);
g.drawLine(634+p,130+r,634+p,145+r);

g.drawLine(623+p,145+r,627+p,145+r);
g.drawLine(632+p,145+r,636+p,145+r);

}







p+=5;
}
if(count<340){

{
g.setColor(Color.cyan);
g.fillOval(620+p,95+r,20,20);

g.setColor(Color.red);
g.fillOval(622+p,100+r,5,5);
g.fillOval(630+p,100+r,5,5);
g.drawArc(625+p,104+r,5,5,0,-180);

g.setColor(Color.green);
g.fillRect(622+p,115+r,15,15);
g.setColor(Color.black);
g.drawLine(622+p,118+r,612+p,123+r);
g.drawLine(612+p,123+r,622+p,128+r);

g.drawLine(637+p,118+r,647+p,123+r);
g.drawLine(647+p,123+r,637+p,128+r);

g.drawLine(625+p,130+r,625+p,145+r);
g.drawLine(634+p,130+r,634+p,145+r);

g.drawLine(623+p,145+r,627+p,145+r);
g.drawLine(632+p,145+r,636+p,145+r);

}
}
if(count>366)
{

{
g.setColor(Color.cyan);
g.fillOval(620+p,95+r,20,20);

g.setColor(Color.red);
g.fillOval(622+p,100+r,5,5);
g.fillOval(630+p,100+r,5,5);
g.drawArc(625+p,104+r,5,5,0,-180);

g.setColor(Color.green);
g.fillRect(622+p,115+r,15,15);
g.setColor(Color.black);

g.drawLine(622+p,122+r,612+p,122+r);
g.drawLine(612+p,122+r,612+p,110+r);

g.drawLine(637+p,122+r,647+p,122+r);
g.drawLine(647+p,122+r,647+p,110+r);



g.drawLine(625+p,130+r,625+p,145+r);
g.drawLine(634+p,130+r,634+p,145+r);

g.drawLine(623+p,145+r,627+p,145+r);
g.drawLine(632+p,145+r,636+p,145+r);

}

r+=5;
}


if(count==272){au.play();}
if(count==323){au1.play();au.stop();}
if(count==366){au1.stop();au2.play();}

if(count>=309)

{

g.setColor(Color.white);
g.fillOval(535+y8,101,20,20);
Color c=new Color(0,0,255);
g.setColor(c);
g.fillRect(537+y8,121,15,15);
g.setColor(Color.red);
g.fillOval(544+y8,107,6,6);
g.setColor(Color.black);


g.drawLine(541+y8,136,535+y8,144);
g.drawLine(535+y8,144,537+y8,146);
g.drawLine(545+y8,136,553+y8,141);
g.drawLine(553+y8,141,543+y8,146);
g.drawLine(546+y8,145,545+y8,145);


g.drawLine(545+y8,129,553+y8,134);
g.drawLine(558+y8,134,559+y8,128);
g.drawLine(562+y8,128,561+y8,128);
g.drawLine(552+y8,129,555+y8,123);
g.drawLine(558+y8,123,557+y8,123);
if(count<323 || (count>340 && count<366))
y8+=5;
}


if(count>480)
{
g.setColor(Color.green);
g.setFont(new Font("Arial",Font.BOLD+Font.ITALIC,30));
g.drawString("MISS U Sarvesh Yadav",380,100);
}














g.setColor(Color.black);
g.drawLine(250,330,450,330);
g.drawLine(250,510,450,510);
g.drawLine(250,420,450,420);

g.drawLine(800,330,1000,330);
g.drawLine(800,510,1000,510);
g.drawLine(800,420,1000,420);















}public void loop()
{} public void play(){}
}

/*<applet code="A" width=1350 height=1350>
</applet>*/