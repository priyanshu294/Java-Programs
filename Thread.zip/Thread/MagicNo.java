import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class MagicNo extends JFrame implements ActionListener
{
    JButton b1=new JButton("1");
    JButton b2=new JButton("10");
    JButton b3=new JButton("7");
    JButton b4=new JButton("18");
    JButton b5=new JButton("15");
    JButton b6=new JButton("20");
    JButton b7=new JButton("11");
    JButton b8=new JButton("4");
    JButton b9=new JButton("19");
    JButton b10=new JButton("14");
    JButton b11=new JButton("5");
    JButton b12=new JButton("21");
    JButton b13=new JButton("24");
    JButton b14=new JButton("2");
    JButton b15=new JButton("9");
    JButton b16=new JButton("23");
    JButton b17=new JButton("17");
    JButton b18=new JButton("6");
    JButton b19=new JButton("13");
    JButton b20=new JButton("22");
    JButton b21=new JButton("27");
    JButton b22=new JButton("3");
    JButton b23=new JButton("26");
    JButton b24=new JButton("25");
    JButton b25=new JButton("8");
    JButton b26=new JButton("12");
    JButton b27=new JButton("16");
    JButton b28=new JButton("1st Line");
    JButton b29=new JButton("2nd Line");
    JButton b30=new JButton("3rd Line");
    JButton b31=new JButton("New Game");
    JLabel l1=new JLabel("Select a number and");
    JLabel l2=new JLabel("press the line where the number is.....");
    JLabel l3=new JLabel("~~MAGIC NUMBER By JT~~");
    int a1[]=new int[9];
    int a2[]=new int[9];
    int a3[]=new int[9];
    int c=0;
    
    JFrame f=new JFrame();
    Container cc;

    void logic()
    {
                a1[0]=Integer.parseInt(b1.getLabel());
                a1[1]=Integer.parseInt(b2.getLabel());
                a1[2]=Integer.parseInt(b3.getLabel());
                a1[3]=Integer.parseInt(b4.getLabel());
                a1[4]=Integer.parseInt(b5.getLabel());
                a1[5]=Integer.parseInt(b6.getLabel());
                a1[6]=Integer.parseInt(b7.getLabel());
                a1[7]=Integer.parseInt(b8.getLabel());
                a1[8]=Integer.parseInt(b9.getLabel());
                
                a2[0]=Integer.parseInt(b10.getLabel());
                a2[1]=Integer.parseInt(b11.getLabel());
                a2[2]=Integer.parseInt(b12.getLabel());
                a2[3]=Integer.parseInt(b13.getLabel());
                a2[4]=Integer.parseInt(b14.getLabel());
                a2[5]=Integer.parseInt(b15.getLabel());
                a2[6]=Integer.parseInt(b16.getLabel());
                a2[7]=Integer.parseInt(b17.getLabel());
                a2[8]=Integer.parseInt(b18.getLabel());
                
                a3[0]=Integer.parseInt(b19.getLabel());
                a3[1]=Integer.parseInt(b20.getLabel());
                a3[2]=Integer.parseInt(b21.getLabel());
                a3[3]=Integer.parseInt(b22.getLabel());
                a3[4]=Integer.parseInt(b23.getLabel());
                a3[5]=Integer.parseInt(b24.getLabel());
                a3[6]=Integer.parseInt(b25.getLabel());
                a3[7]=Integer.parseInt(b26.getLabel());
                a3[8]=Integer.parseInt(b27.getLabel());
                
    }

    public MagicNo()
    {
        f.setVisible(true);
        f.setSize(700,400);
        f.setLayout(null);
        f.setTitle("MAGIC NUMBER");
        f.setLocation(300,120);
        
        cc=f.getContentPane();

        cc.setBackground(Color.BLACK);

        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.GREEN);

        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.GREEN);

        b3.setBackground(Color.BLACK);
        b3.setForeground(Color.GREEN);

        b4.setBackground(Color.BLACK);
        b4.setForeground(Color.GREEN);

        b5.setBackground(Color.BLACK);
        b5.setForeground(Color.GREEN);

        b6.setBackground(Color.BLACK);
        b6.setForeground(Color.GREEN);

        b7.setBackground(Color.BLACK);
        b7.setForeground(Color.GREEN);

        b8.setBackground(Color.BLACK);
        b8.setForeground(Color.GREEN);

        b9.setBackground(Color.BLACK);
        b9.setForeground(Color.GREEN);

        b10.setBackground(Color.BLACK);
        b10.setForeground(Color.GREEN);

        b11.setBackground(Color.BLACK);
        b11.setForeground(Color.GREEN);

        b12.setBackground(Color.BLACK);
        b12.setForeground(Color.GREEN);

        b13.setBackground(Color.BLACK);
        b13.setForeground(Color.GREEN);

        b14.setBackground(Color.BLACK);
        b14.setForeground(Color.GREEN);

        b15.setBackground(Color.BLACK);
        b15.setForeground(Color.GREEN);

        b16.setBackground(Color.BLACK);
        b16.setForeground(Color.GREEN);

        b17.setBackground(Color.BLACK);
        b17.setForeground(Color.GREEN);

        b18.setBackground(Color.BLACK);
        b18.setForeground(Color.GREEN);

        b19.setBackground(Color.BLACK);
        b19.setForeground(Color.GREEN);

        b20.setBackground(Color.BLACK);
        b20.setForeground(Color.GREEN);

        b21.setBackground(Color.BLACK);
        b21.setForeground(Color.GREEN);

        b22.setBackground(Color.BLACK);
        b22.setForeground(Color.GREEN);

        b23.setBackground(Color.BLACK);
        b23.setForeground(Color.GREEN);

        b24.setBackground(Color.BLACK);
        b24.setForeground(Color.GREEN);

        b25.setBackground(Color.BLACK);
        b25.setForeground(Color.GREEN);

        b26.setBackground(Color.BLACK);
        b26.setForeground(Color.GREEN);

        b27.setBackground(Color.BLACK);
        b27.setForeground(Color.GREEN);

        b28.setBackground(Color.BLACK);
        b28.setForeground(Color.GREEN);

        b29.setBackground(Color.BLACK);
        b29.setForeground(Color.GREEN);

        b30.setBackground(Color.BLACK);
        b30.setForeground(Color.GREEN);

        b31.setBackground(Color.BLACK);
        b31.setForeground(Color.GREEN);

        Font ff=new Font("Arial",Font.BOLD,15);
        Font fff=new Font("Arial",Font.BOLD,50);
        l3.setFont(fff);

        l3.setBackground(Color.BLACK);
        l3.setForeground(Color.GREEN);

        b31.setBackground(Color.BLACK);
        b31.setForeground(Color.GREEN);


        b1.setFont(ff);
        b2.setFont(ff);
        b3.setFont(ff);
        b4.setFont(ff);
        b5.setFont(ff);
        b6.setFont(ff);
        b7.setFont(ff);
        b8.setFont(ff);
        b9.setFont(ff);
        b10.setFont(ff);
        b11.setFont(ff);
        b12.setFont(ff);
        b13.setFont(ff);
        b14.setFont(ff);
        b15.setFont(ff);
        b16.setFont(ff);
        b17.setFont(ff);
        b18.setFont(ff);
        b19.setFont(ff);
        b20.setFont(ff);
        b21.setFont(ff);
        b22.setFont(ff);
        b23.setFont(ff);
        b24.setFont(ff);
        b25.setFont(ff);
        b26.setFont(ff);
        b27.setFont(ff);
        b28.setFont(ff);
        b29.setFont(ff);
        b30.setFont(ff);
        b31.setFont(ff);


        b1.setBounds(50,150,50,50); cc.add(b1);
        b2.setBounds(100,150,50,50); cc.add(b2);
        b3.setBounds(150,150,50,50); cc.add(b3);
        b4.setBounds(200,150,50,50); cc.add(b4);
        b5.setBounds(250,150,50,50); cc.add(b5);
        b6.setBounds(300,150,50,50); cc.add(b6);
        b7.setBounds(350,150,50,50); cc.add(b7);
        b8.setBounds(400,150,50,50); cc.add(b8);
        b9.setBounds(450,150,50,50); cc.add(b9);
        b10.setBounds(50,220,50,50); cc.add(b10);
        b11.setBounds(100,220,50,50); cc.add(b11);
        b12.setBounds(150,220,50,50); cc.add(b12);
        b13.setBounds(200,220,50,50); cc.add(b13);
        b14.setBounds(250,220,50,50); cc.add(b14);
        b15.setBounds(300,220,50,50); cc.add(b15);
        b16.setBounds(350,220,50,50); cc.add(b16);
        b17.setBounds(400,220,50,50); cc.add(b17);
        b18.setBounds(450,220,50,50); cc.add(b18);
        b19.setBounds(50,290,50,50); cc.add(b19);
        b20.setBounds(100,290,50,50); cc.add(b20);
        b21.setBounds(150,290,50,50); cc.add(b21);
        b22.setBounds(200,290,50,50); cc.add(b22);
        b23.setBounds(250,290,50,50); cc.add(b23);
        b24.setBounds(300,290,50,50); cc.add(b24);
        b25.setBounds(350,290,50,50); cc.add(b25);
        b26.setBounds(400,290,50,50); cc.add(b26);
        b27.setBounds(450,290,50,50); cc.add(b27);
        
        b28.setBounds(550,150,100,50); cc.add(b28);
        b29.setBounds(550,220,100,50); cc.add(b29);
        b30.setBounds(550,290,100,50); cc.add(b30);
        b31.setBounds(500,380,200,50); cc.add(b31);
        
        //l1.setBounds(50,260,200,50); cc.add(l1);
        //l2.setBounds(50,310,220,50); cc.add(l2);

        l3.setBounds(10,50,700,100);cc.add(l3);

        b28.addActionListener(this);
        b29.addActionListener(this);
        b30.addActionListener(this);
        b31.addActionListener(this);

         f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

        
    public void actionPerformed(ActionEvent ae)
        {
           if(ae.getSource()==b31)
           {
                b1.setLabel("5");
                b2.setLabel("27");
                b3.setLabel("10");
                b4.setLabel("14");
                b5.setLabel("26");
                b6.setLabel("19");
                b7.setLabel("1");
                b8.setLabel("23");
                b9.setLabel("8");
                b10.setLabel("18");
                b11.setLabel("3");
                b12.setLabel("24");
                b13.setLabel("15");
                b14.setLabel("11");
                b15.setLabel("20");
                b16.setLabel("2");
                b17.setLabel("25");
                b18.setLabel("21");
                b19.setLabel("7");
                b20.setLabel("16");
                b21.setLabel("4");
                b22.setLabel("12");
                b23.setLabel("17");
                b24.setLabel("22");
                b25.setLabel("6");
                b26.setLabel("9");
                b27.setLabel("13");
                
                c=0;
            }
        
        
        if(ae.getSource()==b28)
            {
                logic();
                
                b1.setLabel(""+a2[0]);
                b10.setLabel(""+a2[1]);
                b19.setLabel(""+a2[2]);
                b2.setLabel(""+a2[3]);
                b11.setLabel(""+a2[4]);
                b20.setLabel(""+a2[5]);
                b3.setLabel(""+a2[6]);
                b12.setLabel(""+a2[7]);
                b21.setLabel(""+a2[8]);
                b4.setLabel(""+a1[0]);
                b13.setLabel(""+a1[1]);
                b22.setLabel(""+a1[2]);
                b5.setLabel(""+a1[3]);
                b14.setLabel(""+a1[4]);
                b23.setLabel(""+a1[5]);
                b6.setLabel(""+a1[6]);
                b15.setLabel(""+a1[7]);
                b24.setLabel(""+a1[8]);
                b7.setLabel(""+a3[0]);
                b16.setLabel(""+a3[1]);
                b25.setLabel(""+a3[2]);
                b8.setLabel(""+a3[3]);
                b17.setLabel(""+a3[4]);
                b26.setLabel(""+a3[5]);
                b9.setLabel(""+a3[6]);
                b18.setLabel(""+a3[7]);
                b27.setLabel(""+a3[8]);
                
                c++;
                if(c>3)
                {
                    dis();
                }
            }
        
        
            if(ae.getSource()==b29)
            {
                logic();

                b1.setLabel(""+a1[0]);
                b10.setLabel(""+a1[1]);
                b19.setLabel(""+a1[2]);
                b2.setLabel(""+a1[3]);
                b11.setLabel(""+a1[4]);
                b20.setLabel(""+a1[5]);
                b3.setLabel(""+a1[6]);
                b12.setLabel(""+a1[7]);
                b21.setLabel(""+a1[8]);
                b4.setLabel(""+a2[0]);
                b13.setLabel(""+a2[1]);
                b22.setLabel(""+a2[2]);
                b5.setLabel(""+a2[3]);
                b14.setLabel(""+a2[4]);
                b23.setLabel(""+a2[5]);
                b6.setLabel(""+a2[6]);
                b15.setLabel(""+a2[7]);
                b24.setLabel(""+a2[8]);
                b7.setLabel(""+a3[0]);
                b16.setLabel(""+a3[1]);
                b25.setLabel(""+a3[2]);
                b8.setLabel(""+a3[3]);
                b17.setLabel(""+a3[4]);
                b26.setLabel(""+a3[5]);
                b9.setLabel(""+a3[6]);
                b18.setLabel(""+a3[7]);
                b27.setLabel(""+a3[8]);
                
                c++;
                if(c>3)
                {
                    dis();
                }
            }
        
            if(ae.getSource()==b30)
            {
                logic();

                b1.setLabel(""+a1[0]);
                b10.setLabel(""+a1[1]);
                b19.setLabel(""+a1[2]);
                b2.setLabel(""+a1[3]);
                b11.setLabel(""+a1[4]);
                b20.setLabel(""+a1[5]);
                b3.setLabel(""+a1[6]);
                b12.setLabel(""+a1[7]);
                b21.setLabel(""+a1[8]);
                b4.setLabel(""+a3[0]);
                b13.setLabel(""+a3[1]);
                b22.setLabel(""+a3[2]);
                b5.setLabel(""+a3[3]);
                b14.setLabel(""+a3[4]);
                b23.setLabel(""+a3[5]);
                b6.setLabel(""+a3[6]);
                b15.setLabel(""+a3[7]);
                b24.setLabel(""+a3[8]);
                b7.setLabel(""+a2[0]);
                b16.setLabel(""+a2[1]);
                b25.setLabel(""+a2[2]);
                b8.setLabel(""+a2[3]);
                b17.setLabel(""+a2[4]);
                b26.setLabel(""+a2[5]);
                b9.setLabel(""+a2[6]);
                b18.setLabel(""+a2[7]);
                b27.setLabel(""+a2[8]);
                
                c++;
                if(c>3)
                {
                    dis();
                }
            }
        
        
    }
    
    void dis()
    {
        JOptionPane.showMessageDialog(null,"Your selected number is -- "+b14.getLabel());
    }
    
    public static void main(String args[])
    {
        new MagicNo();
    }
}