public class Stock 
	{
	int goods;
	public synchronized void addGoods(int i)
		{
		goods+=i;
		System.out.println("Added goods are : "+i);
		System.out.println("Total goods are : "+goods);
		notify();
		}
	public synchronized int getGoods(int i)
		{
		while(true)
			{
			if(goods>=i)
				{
				goods-=i;
				System.out.println("goods deducted are : "+i);
				System.out.println("Total goods are : "+goods);
				break;
				}else{
				System.out.println("!!!Insufficient Goods.!!!")	;
				try{
				wait();
				}catch(Exception ee)
					{
					}
				}
			}
		return goods;
		}
	public static void main(String args[])	
		{
		Stock ss=new Stock();
		Producer p=new Producer(ss);
		Consumer c=new Consumer(ss);
		try{
		Thread.sleep(10000);
		}catch(InterruptedException ie)
			{
			}
		p.kill();
		c.kill();
		}
	}
	
		