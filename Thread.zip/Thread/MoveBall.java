import java.awt.*;
import java.awt.event.*;
import java.applet.*;
public class MoveBall extends Applet implements Runnable,ActionListener
        {
        Thread t;
        Button b1,b2,b3,b4;
        int x;
        public void init()
                {
                b1=new Button("Life");
                b2=new Button("Kill");
                b3=new Button("Suspend");
                b4=new Button("Resume");
                b1.addActionListener(this);
                b2.addActionListener(this);
                b3.addActionListener(this);
                b4.addActionListener(this);
                add(b1);
                add(b2);
                add(b3);
                add(b4);
                }
        public void actionPerformed(ActionEvent ae)
                {
                if((ae.getSource()==b1)&&(t==null))
                        {
                        t=new Thread(this);
                        t.start();
                        }
                else if((ae.getSource()==b2)&&(t!=null))
                        {
                        t.stop();
                        t=null;
                        }
                else if((ae.getSource()==b3)&&(t!=null))
                        {
                        t.suspend();
                        }
                else if((ae.getSource()==b4)&&(t!=null))
                        {
                        t.resume();
                        }
               }
        public void run()
                {
                while(true)
                        {
                        for(x=1;x<getSize().width;x+=20)
                                {
                                repaint();
                                try{
                                Thread.sleep(100);
                                }catch(Exception ee)
                                        {
                                        }
                                }
                        }
                }
        public void paint(Graphics g)
                {
                g.setColor(Color.red);
                g.fillOval(x,200,50,50);
                }
        }
/*<applet code="MoveBall" width=500 height=500>
</applet>*/






