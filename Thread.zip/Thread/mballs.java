import java.awt.*;
import java.awt.event.*;
import java.applet.*;
public class mballs extends Applet implements Runnable,ActionListener
{
Thread t=null;
Button b1,b2,b3,b4;
int l;
TextField tf2,tf1;
Label l1,l2;
	public void init()
      {

	l1=new Label("Enter Speed in ms");
	l2=new Label("No of Balls");
	l1.setForeground(Color.orange);
	l2.setForeground(Color.orange);
	tf1=new TextField(5);
	tf2=new TextField(5);
	b1=new Button("start");
	b2=new Button("stop");
	b3=new Button("pause");
	b4=new Button("Resume");
	b1.addActionListener(this);
	b2.addActionListener(this);
	b3.addActionListener(this);
	b4.addActionListener(this);
	setBackground(Color.black);
	add(l1);
	add(tf1);
	add(l2);
	add(tf2);
	add(b1);
	add(b2);
	add(b3);
	add(b4);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if((ae.getSource()==b1)&&(t==null))
		{
		t=new Thread(this);
		t.start();
		}
		else if((ae.getSource()==b2)&&(t!=null))
		{
		t.stop();
		t=null;
		}
		else if((ae.getSource()==b3)&&(t!=null))
		{
		t.suspend();
		}
		else if((ae.getSource()==b4)&&(t!=null))
		{
		t.resume();
		}
	}
	public void run()
	{
	for(;;)
	{
	try
		{
		repaint();
		Thread.sleep(Integer.parseInt(tf1.getText()));
		}
	catch(Exception e){}
	}
	}
	public void paint(Graphics g)
	{

	for(int k=0;k<(Integer.parseInt(tf2.getText()))%1000;k++)
	{
	l=((int)(Math.random()*1000))%100;
	g.setColor(new Color(((int)(Math.random()*1000))%254,((int)(Math.random()*1000))%254,((int)(Math.random()*1000))%254));
	g.fillOval(((int)(Math.random()*1000))%500+100,((int)(Math.random()*1000))%500+100,l,l);
	}
	}
}
/*<applet code="mballs" width=800 height=650>
</applet>*/


