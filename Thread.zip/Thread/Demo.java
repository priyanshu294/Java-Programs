class Demo
	{
	public void display(String name)
		{
		System.out.println("Running Thread name is : "+name);
		try{
		Thread.sleep(1000);
		}catch(InterruptedException ie)	
			{
			}
		System.out.println("dead thread name is : "+name);
		}
	}
	