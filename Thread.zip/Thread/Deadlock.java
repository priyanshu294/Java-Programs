public class Deadlock
	{
	public static void main(String args[])
		{
		final String s1="Java";
		final String s2="Technocrat";
		Thread t1=new Thread()
			{
			public void run()
			{
			synchronized(s1)
			{
			System.out.println("Thread1 locked on : s1 Object.");
			try{
			Thread.sleep(1000);
			}catch(InterruptedException ie)
						{
						}
				synchronized(s2)
				{
				System.out.println("Thread1 locked on : s2 object.");
				}
			}
			}
			};
		Thread t2=new Thread()
			{
			public void run()
			{
			synchronized(s2)	
			{
			System.out.println("Thread2 locked on : s2 Object.");
			try{
			Thread.sleep(1000);
			}catch(InterruptedException ie)
				{
				}
			synchronized(s1)
				{
				System.out.println("Thread2 locked on : s1 Object.");
				}
			}
			}
			};
		t1.start();
		t2.start();
		}
	}	
						