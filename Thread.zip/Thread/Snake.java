//Dot snake game
import java.net.*;
import java.io.IOException.*;
import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import java.awt.Dimension;
/*
<applet code="Snake" width=350 height=350>
</applet>
*/
public class Snake extends Applet implements Runnable ,KeyListener
{
	int x1,y1,x0,y0,len=70,dir=1,i,j,f=0,r=0,score;
	public int x,y,xx,yy;
	int s[][]=new int[7][1000];
	Thread t;

	public void init()
	{	
 
		setBackground(Color.BLACK);
		addKeyListener(this);
		t=new Thread(this);
		t.start();
	}
	public void run()
	{
		Dimension dim =new Dimension(350,350);	
		xx =(int)(dim.getWidth());
		yy =(int)(dim.getHeight());
		x1=xx/2;		
		y1=yy/2;
		s[0][0]=0;
		s[1][0]=x1;	
		s[2][0]=y1;	
		s[3][0]=len;	
		s[4][0]=dir;	
		s[6][0]=y1;	

		
	
		Random ran = new Random();
		 x = ran.nextInt(xx);	

		 y = ran.nextInt(yy);	
			
		for(;;)
		{
			
			
			try{
				t.sleep(40);	}
			catch(Exception e)
			{}
			if(r<=f)
			{
				if((s[1][f]==x || s[1][f]==x+1) && (s[2][f]==y || s[2][f]==y+1))	//in this program i have considered a ractangle of 1X1 rather than single point. 
				{																	//check whether snake met to point or not?
					s[3][r]+=25;	
					score++;	
					
					 x = ran.nextInt(xx);
					 y = ran.nextInt(yy);	
				}
				if(r<f)
				{
				
					if(s[3][r]<=0)
					{
						r++;
					}
					s[3][r]--;	
					
					if(s[4][r]==1)
					{
							s[5][r]=s[1][r]-s[3][r];
							s[6][r]=s[2][r];
					}
					if(s[4][r]==2)
					{
							s[5][r]=s[1][r];
							s[6][r]=s[2][r]-s[3][r];
					}
					if(s[4][r]==3)
					{
							s[5][r]=s[1][r]+s[3][r];
							s[6][r]=s[2][r];
					}
					if(s[4][r]==4)
					{
							s[5][r]=s[1][r];
							s[6][r]=s[2][r]+s[3][r];
					}
					
					
					s[3][f]++;
					if(s[4][f]==1)
					{
							s[1][f]=s[5][f]+s[3][f];
							s[2][f]=s[6][f];
					}
					if(s[4][f]==2)
					{	
						s[1][f]=s[5][f];
						s[2][f]=s[6][f]+s[3][f];	
					
					}
					if(s[4][f]==3)
					{
							
							s[1][f]=s[5][f]-s[3][f];
							s[2][f]=s[6][f];
					}
					if(s[4][f]==4)
					{
							s[1][f]=s[5][f];
							s[2][f]=s[6][f]-s[3][f];
							
					}
					
				}
				
				
				if(r==f)
				{
					if(s[4][r]==1)
					{
							s[1][f]++;
							s[5][r]=s[1][r]-s[3][r];
					}
					if(s[4][f]==2)
					{	s[2][f]++;
						s[6][r]=s[2][r]-s[3][r];
					}
					if(s[4][f]==3)
					{		s[1][f]--;
							s[5][r]=s[1][r]+s[3][r];
					}
					if(s[4][f]==4)
					{		s[6][r]=s[2][r]+s[3][r];
							s[2][f]--;
					}
				}
				
				
				
					if(s[1][f]>xx-1)
					{
						f++;
						s[4][f]=s[4][f-1];
						s[1][f]=0;
						s[5][f]=0;
						s[2][f]=s[2][f-1];
						s[6][f]=s[6][f-1];
						s[3][f]=0;
					}
					if(s[2][f]>yy-1)
					{
						f++;
						s[4][f]=s[4][f-1];
						s[2][f]=0;
						s[6][f]=0;
						s[1][f]=s[1][f-1];
						s[5][f]=s[5][f-1];
						s[3][f]=0;
					}
					if(s[1][f]<0)
					{
						f++;
						s[4][f]=s[4][f-1];
						s[1][f]=xx-1;
						s[5][f]=xx-1;
						s[2][f]=s[2][f-1];
						s[6][f]=s[6][f-1];
						s[3][f]=0;
					}
					if(s[2][f]<0)
					{
						f++;
						s[4][f]=s[4][f-1];
						s[2][f]=yy-1;
						s[6][f]=yy-1;
						s[1][f]=s[1][f-1];
						s[5][f]=s[5][f-1];
						s[3][f]=0;
					}
					
					
					
					for(int j=r;j<f;j++)
					{
					
						if(s[4][j]==2||s[4][j]==4)
						{
							if(s[1][f]==s[1][j] )
							{	
								if(s[2][j]>s[6][j])
								{
									if(s[2][f]<=s[2][j] && s[2][f]>=s[6][j])
									{r=f+1;}
									
								}
								else
								{
									if(s[2][f]>=s[2][j] && s[2][f]<=s[6][j])
									{r=f+1;}
									
								}
							}
						}
					
						if(s[4][j]==1||s[4][j]==3)
						{
							if(s[2][f]==s[2][j] )
							{
								if(s[1][j]>s[5][j])
								{
									if(s[1][f]<=s[1][j] && s[1][f]>=s[5][j])
									{r=f+1;}
									
								}
								else
								{
									if(s[1][f]>=s[1][j] && s[1][f]<=s[5][j])
									{r=f+1;}
								}
							}
						}
					}
			}	
			repaint();
		}
	}
	public void keyPressed(KeyEvent e)
	{
	
		if(r<=f)
		{
			int n = e.getKeyCode();
			f++;
			s[5][f]=s[1][f-1];
			s[1][f]=s[1][f-1];
			s[6][f]=s[2][f-1];
			s[2][f]=s[2][f-1];
			s[3][f]=0;
			if(n==KeyEvent.VK_RIGHT)
			{
				if(s[4][f-1]!=3)
				s[4][f]=1;
				else
				f--;
			}
			if(n==KeyEvent.VK_LEFT)
			{
				if(s[4][f-1]!=1)
				s[4][f]=3;
				else
				f--;
			}
			if(n==KeyEvent.VK_UP)
			{
				
				if(s[4][f-1]!=2)
				s[4][f]=4;
				else
				f--;
			}
			if(n==KeyEvent.VK_DOWN)
			{
				if(s[4][f-1]!=4) 
				s[4][f]=2;
				else
				f--;
			}
		}
		repaint();
	}
	public void keyTyped(KeyEvent e)
	{}
	public void keyReleased(KeyEvent e)
	{}
	public void paint(Graphics g)
	{
		if(r<=f)
{
			for(i=r;i<=f;i++)
			{
				g.setColor(Color.WHITE);
				g.drawLine(s[1][i],s[2][i],s[5][i],s[6][i]);
				g.setColor(Color.PINK);
				g.drawRect(x,y,2,2);
				
			}
		}
		else
		{	
			Image background;
			java.net.URL backgroundURL;
if(score<=5)
{
			backgroundURL=this.getClass().getResource("loser.JPG");
			background=getImage(backgroundURL);
			g.drawImage(background,0,0,null);
                        g.setColor(Color.BLACK);
                        g.setFont(new Font("Arial Black",Font.BOLD,xx/10));
			g.setColor(Color.BLACK);
			g.drawString("    Game Over" ,xx/4,((int)(yy/2)+260));
			g.drawString("    Your Score is : "+score,xx/6,(yy/2)+285);
			g.setColor(Color.RED);
			g.drawString("Copyright @ JAVA TECHNOCRAT:"+"",xx/12,((yy/2)+350));
}
else if((score>5)&&(score<10))
{
backgroundURL=this.getClass().getResource("congrats.JPG");
			background=getImage(backgroundURL);
			g.drawImage(background,0,0,null);
			g.setColor(Color.GREEN);
			g.setFont(new Font("serif",Font.BOLD,xx/10));
			g.setColor(Color.BLACK);
			g.drawString("Game Over" ,xx/4,((int)(yy/2)+260));
			g.drawString("Your Score is : "+score,xx/6,(yy/2)+285);
			g.setColor(Color.WHITE);
			g.drawString("Copyright @ JAVA TECHNOCRAT:"+"",xx/12,((yy/2)+350));
}
else{


backgroundURL=this.getClass().getResource("winner.JPG");
			background=getImage(backgroundURL);
			g.drawImage(background,0,0,null);
			g.setColor(Color.GREEN);
			g.setFont(new Font("serif",Font.BOLD,xx/10));
			g.setColor(Color.BLUE);
			g.drawString("Game Over" ,xx/4,((int)(yy/2)+260));
			g.drawString("Your Score is : "+score,xx/6,(yy/2)+285);
			g.setColor(Color.WHITE);
			g.drawString("Copyright @ JAVA TECHNOCRAT"+"",xx/12,((yy/2)+350));
}
			
		}
	}
}
